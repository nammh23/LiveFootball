//
//  FIConfig.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FIConfig.h"

@implementation FIConfig

NSString* const BACKGROUND_IMAGE_TABBAR = @"tabbar_background";
NSString* const BACKGROUND_IMAGE_NAVIGATION_BAR = @"green-background";
NSString* const BACKGROUND_IMAGE_TABLE = @"white-background";
NSString* const BACKGROUND_IMAGE_DATE_VIEW = @"gray-background";
NSString* const BACKGROUND_IMAGE_HIGHLIGHTED = @"green-background";
NSString* const BACKGROUND_IMAGE_TEAM_INFO_IPHONE = @"bg_team_iphone";
NSString* const BACKGROUND_IMAGE_TEAM_INFO_IPAD = @"bg_team_ipad";
NSString* const BACKGROUND_IMAGE_PLAYER_INFO_IPHONE = @"bg_player_iphone";
NSString* const BACKGROUND_IMAGE_PLAYER_INFO_IPAD = @"bg_player_ipad";

NSString* const NAVIGATION_BAR_FONT_NAME = @"Helvetica";
const float NAVIGATION_BAR_FONT_SIZE = 15.0f;

const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED = 57/255.0;
const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN = 134/255.0;
const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE = 34/255.0;
const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA = 1.0f;
const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_BRIGHTNESS_SHIFT = 50.0f / 255.0;

const float DEFAULT_NAVIGATION_BAR_HEIGHT = 44.0f;

///Whether a @a keyName key existed in settings
+(BOOL)keyExisted:(NSString *)keyName {
    @synchronized(self) {
        return [[NSUserDefaults standardUserDefaults] objectForKey:keyName] != nil;
    }
}

//Reload score timeval
static const float SETTING_RELOAD_SCORE_TIMEVAL_DEFAULT = 60.0f;//seconds
NSString* const SETTING_RELOAD_SCORE_TIMEVAL_KEY = @"reloadScoreTimeval";
+(float)getReloadScoreTimeval {
    @synchronized(self) {
        if ([FIConfig keyExisted:SETTING_RELOAD_SCORE_TIMEVAL_KEY]) {
            return [[NSUserDefaults standardUserDefaults] integerForKey:SETTING_RELOAD_SCORE_TIMEVAL_KEY];
        } else {
            [FIConfig setReloadScoreTimeval:SETTING_RELOAD_SCORE_TIMEVAL_DEFAULT];
            return SETTING_RELOAD_SCORE_TIMEVAL_DEFAULT;
        }
    }
}

+(void)setReloadScoreTimeval:(float)time{
    @synchronized(self) {
        [[NSUserDefaults standardUserDefaults] setInteger:time forKey:SETTING_RELOAD_SCORE_TIMEVAL_KEY];
    }
}


//new version
NSString* const SETTING_NEW_VERSION_DEFAULT = @"0";
NSString* const SETTING_NEW_VERSION_KEY = @"newVersion";
+(NSString *)getNewVersion {
    @synchronized(self) {
        if ([FIConfig keyExisted:SETTING_NEW_VERSION_KEY]) {
            return [[NSUserDefaults standardUserDefaults] stringForKey:SETTING_NEW_VERSION_KEY];
        } else {
            return SETTING_NEW_VERSION_DEFAULT;
        }
    }
}

+(void)setNewVersion:(NSString *)version {
    @synchronized(self) {
        [[NSUserDefaults standardUserDefaults] setObject:version forKey:SETTING_NEW_VERSION_KEY];
    }
}

//force update
static const ConfigUpdateNotificationOption SETTING_FORCE_UPDATE_DEFAULT = ConfigUpdateNotificationOptionChoice;
NSString* const SETTING_FORCE_UPDATE_KEY = @"forceUpdate";
+(ConfigUpdateNotificationOption)getForceUpdate {
    @synchronized(self) {
        if ([FIConfig keyExisted:SETTING_FORCE_UPDATE_KEY]) {
            return (int)[[NSUserDefaults standardUserDefaults] integerForKey:SETTING_FORCE_UPDATE_KEY];
        } else {
            [FIConfig setForceUpdate:SETTING_FORCE_UPDATE_DEFAULT];
            return SETTING_FORCE_UPDATE_DEFAULT;
        }
    }
}

+(void)setForceUpdate:(ConfigUpdateNotificationOption)update {
    @synchronized(self) {
        [[NSUserDefaults standardUserDefaults] setInteger:update forKey:SETTING_FORCE_UPDATE_KEY];
    }
}

//update message
NSString* const SETTING_UPDATE_MESSAGE_DEFAULT = @"Download more with new version. Update now...";
NSString* const SETTING_UPDATE_MESSAGE_KEY = @"updateMessage";
+(NSString *)getUpdateMessage {
    @synchronized(self) {
        if ([FIConfig keyExisted:SETTING_UPDATE_MESSAGE_KEY]) {
            return [[NSUserDefaults standardUserDefaults] stringForKey:SETTING_UPDATE_MESSAGE_KEY];
        } else {
            return SETTING_UPDATE_MESSAGE_DEFAULT;
        }
    }
}

+(void)setUpdateMessage:(NSString *)message {
    @synchronized(self) {
        [[NSUserDefaults standardUserDefaults] setObject:message forKey:SETTING_UPDATE_MESSAGE_KEY];
    }
}

//new version app store url
NSString* const SETTING_NEW_VERSION_APPSTORE_URL_DEFAULT = nil;
NSString* const SETTING_NEW_VERSION_APPSTORE_URL_KEY = @"newVersionAppStoreURL";
+(NSString *)getNewVersionAppStoreURL {
    @synchronized(self) {
        //        return @"http://itunes.apple.com/app/id757696853";
        if ([FIConfig keyExisted:SETTING_NEW_VERSION_APPSTORE_URL_KEY]) {
            return [[NSUserDefaults standardUserDefaults] stringForKey:SETTING_NEW_VERSION_APPSTORE_URL_KEY];
        } else {
            return SETTING_NEW_VERSION_APPSTORE_URL_DEFAULT;
        }
    }
}

+(void)setNewVersionAppStoreURL:(NSString *)url {
    @synchronized(self) {
        [[NSUserDefaults standardUserDefaults] setObject:url forKey:SETTING_NEW_VERSION_APPSTORE_URL_KEY];
    }
}

+(NSString *)getCurrentVersion {
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
}

+(BOOL)isNewVersionAvailable {
    @synchronized(self) {
        return [[FIConfig getNewVersion] compare:[FIConfig getCurrentVersion] options:NSNumericSearch] == NSOrderedDescending;
    }
}

NSString* const SETTING_ENABLE_BEAUTY_KEY = @"enableBeauty";

@end
