//
//  FIUtil.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//


#import "FIUtil.h"

@implementation FIUtil

NSString* const EMPTY_STRING = @"";

NSString* const LANGUAGE_ENGLISH_STRING = @"en";
NSString* const LANGUAGE_VIETNAMESE_STRING = @"vi";

+(CGRect)getScreenFrameForCurrentOrientation {
    return [FIUtil getScreenFrameForOrientation:[UIApplication sharedApplication].statusBarOrientation];
}

+(CGRect)getScreenFrameForOrientation:(UIInterfaceOrientation)orientation {
    
    UIScreen *screen = [UIScreen mainScreen];
    CGRect fullScreenRect = screen.bounds;
    BOOL statusBarHidden = [UIApplication sharedApplication].statusBarHidden;
    
    //implicitly in Portrait orientation.
    if(orientation == UIInterfaceOrientationLandscapeRight || orientation == UIInterfaceOrientationLandscapeLeft){
        CGRect temp = CGRectZero;
        temp.size.width = fullScreenRect.size.height;
        temp.size.height = fullScreenRect.size.width;
        fullScreenRect = temp;
    }
    
    if(!statusBarHidden){
        CGFloat statusBarHeight = 20;//Needs a better solution, FYI statusBarFrame reports wrong in some cases..
        fullScreenRect.size.height -= statusBarHeight;
    }
    
    return fullScreenRect;
}

+(bool)isWideScreen {
    return [FIUtil getScreenFrameForCurrentOrientation].size.height > 500;
}

+(NSInteger)getDateComponent:(DateComponentType)componentType fromDate:(NSDate*)date {
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    unsigned unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit | NSWeekdayCalendarUnit | NSWeekOfYearCalendarUnit;
    NSDateComponents *comps = [gregorian components:unitFlags fromDate:date];
    
    switch (componentType) {
        case DateComponentTypeWeekDay:
            return [comps weekday];
            break;
            
        case DateComponentTypeWeekOfYear:
            return [comps weekOfYear];
            break;
            
        case DateComponentTypeDay:
            return [comps day];
            break;
            
        case DateComponentTypeMonth:
            return [comps month];
            break;
            
        case DateComponentTypeYear:
            return [comps year];
            break;
            
        default:
            return 0;
            break;
    }
}

+ (NSDate *)addDays:(int)days toDate:(NSDate *)date
{
    NSDateComponents *components= [[NSDateComponents alloc] init];
    [components setDay:days];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    return [calendar dateByAddingComponents:components toDate:date options:0];
}

+(NSString *)getDocumentDirectory {
    @synchronized(self) {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        return [paths firstObject];
    }
}

NSString* const DIRECTORY_TEAM_AVATAR = @"images/teamavatar";
+(NSString*)getTeamAvatarDirectory {
    @synchronized(self) {
        NSString *path = [[FIUtil getDocumentDirectory] stringByAppendingPathComponent:DIRECTORY_TEAM_AVATAR];
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:NULL];
        return path;
    }
}

NSString* const DIRECTORY_PLAYER_AVATAR = @"images/playeravatar";
+(NSString*)getPlayerAvatarDirectory {
    @synchronized(self) {
        NSString *path = [[FIUtil getDocumentDirectory] stringByAppendingPathComponent:DIRECTORY_PLAYER_AVATAR];
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:NULL];
        return path;
    }
}


+(void)deleteFilesAtPath:(NSString *)path {
    @synchronized(self) {
        NSDirectoryEnumerator* dirEnumerator = [[NSFileManager defaultManager] enumeratorAtPath:path];
        NSError* error = nil;
        BOOL result;
        
        NSString* file;
        while (file = [dirEnumerator nextObject]) {
            NSString* filePath = [path stringByAppendingPathComponent:file];
            result = [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
            if (!result && error) {
                NSLog(@"<%@:%@:%d>: Error removing file %@: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, filePath, error);
            }
        }
    }
}

+(NSString*)getStringRepresentationOfMatchStatus:(MatchStatus)status {
    //TODO: LOCALIZATION
    switch (status) {
        case MatchStatusNotStart:
            return @"Not start";
            
        case MatchStatusAboutToStart:
            return @"On going";
            
        case MatchStatusOnGoing:
            return @"Playing";
            
        case MatchStatusHalfTime:
            return @"Hafl time";
            
        case MatchStatusFullTime:
            return @"Full time";
            
        default:
            NSLog(@"<%@:%@:%d>: error when getting string representation for match status %d", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, status );
            return nil;
            break;
    }
}

+(bool)isDate:(NSDate *)date1 sameDay:(NSDate *)date2 {
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    unsigned unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit;
    
    NSDateComponents *comps1 = [gregorian components:unitFlags fromDate:date1];
    NSDateComponents *comps2 = [gregorian components:unitFlags fromDate:date2];
    if ([comps1 year] != [comps2 year]) {
        return NO;
    }
    
    if ([comps1 month] != [comps2 month]) {
        return NO;
    }
    
    if ([comps1 day] != [comps2 day]) {
        return NO;
    }
    
    return YES;
}

#pragma mark - VIEWs

const float TEXT_COLOR_RED = 27.0f / 255;
const float TEXT_COLOR_GREEN = 145.0f / 255;
const float TEXT_COLOR_BLUE = 140.0f / 255;

const float TABBAR_ANIMATION_DURATION = 0.5;

static bool isTabBarHidden = NO;

static const float DEFAULT_TABBAR_HEIGHT = 49.0f;
static float tabBarHeight = DEFAULT_TABBAR_HEIGHT;


+(void)setTabBarHeight:(CGFloat)height {
    @synchronized(self) {
        tabBarHeight = height;
    }
}

+(void)hideTabBar:(UITabBarController *)tabBarController subViewsHeight:(CGFloat)subViewsHeight
{
    @synchronized(self) {
        if (isTabBarHidden) {//already hidden
            return;
        }
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:TABBAR_ANIMATION_DURATION];
        
        for(UIView *view in tabBarController.view.subviews)
        {
            if([view isKindOfClass:[UITabBar class]])
            {
                [view setFrame:CGRectMake(view.frame.origin.x,
                                          subViewsHeight,
                                          view.frame.size.width,
                                          view.frame.size.height)];
            }
            else
            {
                [view setFrame:CGRectMake(view.frame.origin.x,
                                          view.frame.origin.y,
                                          view.frame.size.width,
                                          subViewsHeight)];
            }
        }
        
        [UIView commitAnimations];
        
        isTabBarHidden = YES;
    }
}

+(void)showTabBar:(UITabBarController *)tabBarController subViewsHeight:(CGFloat)subViewsHeight
{
    @synchronized(self) {
        if (!isTabBarHidden) { //already shown
            return;
        }
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:TABBAR_ANIMATION_DURATION];
        for(UIView *view in tabBarController.view.subviews)
        {
            if([view isKindOfClass:[UITabBar class]])
            {
                [view setFrame:CGRectMake(view.frame.origin.x,
                                          subViewsHeight - tabBarHeight,
                                          view.frame.size.width,
                                          view.frame.size.height)];
                
            }
            else
            {
                [view setFrame:CGRectMake(view.frame.origin.x,
                                          view.frame.origin.y,
                                          view.frame.size.width,
                                          subViewsHeight - tabBarHeight)];
            }
        }
        
        [UIView commitAnimations];
        isTabBarHidden = NO;
    }
}

+(void)hideTabBar:(UITabBarController *)tabBarController {
    @synchronized(self) {
        [FIUtil hideTabBar:tabBarController subViewsHeight:[FIUtil getScreenHeightByOrientation]];
    }
}

+(void)showTabBar:(UITabBarController *)tabBarController {
    @synchronized(self) {
        [FIUtil showTabBar:tabBarController subViewsHeight:[FIUtil getScreenHeightByOrientation]];
    }
}

+(CGFloat)getScreenHeightByOrientation {
    @synchronized(self) {
        if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
            return [[UIScreen mainScreen] bounds].size.height;
        } else {
            return [[UIScreen mainScreen] bounds].size.width;
        }
    }
}

@end
