//
//  FIUtil.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "UIKit/UIKit.h"

@interface FIUtil : NSObject

extern NSString* const EMPTY_STRING;

extern NSString* const LANGUAGE_ENGLISH_STRING;
extern NSString* const LANGUAGE_VIETNAMESE_STRING;

+(CGRect)getScreenFrameForCurrentOrientation;
+(CGRect)getScreenFrameForOrientation:(UIInterfaceOrientation)orientation;

/// Whether the device is widescreen (iPhone 5/5S)
+(bool)isWideScreen;

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)

///System Versioning Preprocessor Macros
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

/// Types of components of a date
typedef enum dateComponentType {
    DateComponentTypeWeekDay = 0,
    DateComponentTypeWeekOfYear = 1,
    DateComponentTypeDay = 2,
    DateComponentTypeMonth = 3,
    DateComponentTypeYear = 4
} DateComponentType;

///Get a component of a given date
+(NSInteger)getDateComponent:(DateComponentType)componentType fromDate:(NSDate*)date;

/// Add more @a days days to a given date
+ (NSDate *)addDays:(int)days toDate:(NSDate *)date;

/// Get Document directory of the app
+(NSString *)getDocumentDirectory;

/// Get team avatar directory
+(NSString *)getTeamAvatarDirectory;

/// Get player avatar directory
+(NSString *)getPlayerAvatarDirectory;

/// Delete all files at the given path
+(void)deleteFilesAtPath:(NSString*)path;


/// Statuses of a match
typedef enum matchStatus {
    MatchStatusNotStart = 0,
    MatchStatusAboutToStart = 1,
    MatchStatusOnGoing = 2,
    MatchStatusHalfTime = 3,
    MatchStatusFullTime = 4
} MatchStatus;

+(NSString*)getStringRepresentationOfMatchStatus:(MatchStatus)status;

///Whether 2 dates refer to the same day (same day, month and year, NOT necessary hour, minute and second)
+(bool)isDate:(NSDate*)date1 sameDay:(NSDate*)date2;


#pragma mark - VIEWs
extern const float TEXT_COLOR_RED;
extern const float TEXT_COLOR_GREEN;
extern const float TEXT_COLOR_BLUE;

extern const float TABBAR_ANIMATION_DURATION;

+(void)setTabBarHeight:(CGFloat)height;

///Hide TabBar with subviews height
+(void)hideTabBar:(UITabBarController *)tabBarController subViewsHeight:(CGFloat)subViewsHeight;
///Show TabBar with subviews height
+(void)showTabBar:(UITabBarController *)tabBarController subViewsHeight:(CGFloat)subViewsHeight;

///Hide TabBar with subviews height get from @method +getScreenHeightByOrientation
+(void)hideTabBar:(UITabBarController *)tabBarController;
///Show TabBar with subviews height get from @method +getScreenHeightByOrientation
+(void)showTabBar:(UITabBarController *)tabBarController;

+(CGFloat)getScreenHeightByOrientation;

@end

