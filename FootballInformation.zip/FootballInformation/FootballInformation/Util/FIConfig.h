//
//  FIConfig.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface FIConfig : NSObject

extern NSString* const BACKGROUND_IMAGE_TABBAR;
extern NSString* const BACKGROUND_IMAGE_NAVIGATION_BAR;
extern NSString* const BACKGROUND_IMAGE_TABLE;
extern NSString* const BACKGROUND_IMAGE_DATE_VIEW;
extern NSString* const BACKGROUND_IMAGE_HIGHLIGHTED;
extern NSString* const BACKGROUND_IMAGE_TEAM_INFO_IPHONE;
extern NSString* const BACKGROUND_IMAGE_TEAM_INFO_IPAD;
extern NSString* const BACKGROUND_IMAGE_PLAYER_INFO_IPHONE;
extern NSString* const BACKGROUND_IMAGE_PLAYER_INFO_IPAD;

extern NSString* const NAVIGATION_BAR_FONT_NAME;
extern const float NAVIGATION_BAR_FONT_SIZE;

extern const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED;
extern const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN;
extern const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE;
extern const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA;
extern const float TABLE_CELL_SELECTED_BACKGROUND_COLOR_BRIGHTNESS_SHIFT;

extern const float DEFAULT_NAVIGATION_BAR_HEIGHT;

///Whether a @a keyName key existed in settings
+(BOOL)keyExisted:(NSString *)keyName;

///Get time interval to reload live score
+(float)getReloadScoreTimeval;
///Set time interval to reload live score
+(void)setReloadScoreTimeval:(float)time;

//update
typedef enum {
    ConfigUpdateNotificationOptionNoForce = 0,
    ConfigUpdateNotificationOptionChoice = 1,
    ConfigUpdateNotificationOptionForce = 2
} ConfigUpdateNotificationOption;

+(ConfigUpdateNotificationOption)getForceUpdate;
+(void)setForceUpdate:(ConfigUpdateNotificationOption)update;

+(NSString *)getUpdateMessage;
+(void)setUpdateMessage:(NSString *)message;

+(NSString *)getNewVersionAppStoreURL;
+(void)setNewVersionAppStoreURL:(NSString *)url;

+(NSString *)getCurrentVersion;
+(BOOL)isNewVersionAvailable;

+(NSString *)getNewVersion;
+(void)setNewVersion:(NSString *)version;


@end
