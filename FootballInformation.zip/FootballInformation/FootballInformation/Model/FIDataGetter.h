//
//  FIDataGetter.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FIDataGetter : NSObject
extern NSString* const kGetTeamDataSucceeded;
extern NSString* const kGetTeamDataFailed;

/**
 * Get team data.
 * Post notification with name kGetTeamDataSucceeded/kGetTeamDataFailed when succeeded or failed.
 * If succeeded, notification data contains an array of FITeamData(s), associated with key kGetTeamDataSucceeded
 * NOTE: NOT get manager and player list here, use getTeamDataFull: instead.
 */
+(void)getTeamData;

extern NSString* const kGetScheduleDataSucceeded;
extern NSString* const kGetScheduleDataFailed;

/**
 * Get schedule data.
 * Post notification with name kGetScheduleDataSucceeded/kGetScheduleDataFailed when succeeded or failed.
 * If succeeded, notification data contains an array of FIScheduleMatchData(s), associated with key kGetScheduleDataSucceeded
 */
+(void)getScheduleData;

extern NSString* const kGetTableDataSucceeded;
extern NSString* const kGetTableDataFailed;

/**
 * Get Table data.
 * Post notification with name kGetTableDataSucceeded/kGetTableDataFailed when succeeded or failed.
 * If succeeded, notification data contains an array of FITableTeamData(s), associated with key kGetTableDataSucceeded
 */
+(void)getTableData:(NSInteger)leagueID;

extern const int TEST_MATCH_ID;

extern NSString* const kGetCastingDataSucceeded;
extern NSString* const kGetCastingDataSucceededMatchId;
extern NSString* const kGetCastingDataFailed;

/**
 * Get casting data of a match.
 * Post notification with name kGetCastingDataSucceeded/kGetCastingDataFailed when succeeded or failed.
 * If succeeded, notification data contains an array of FICastingData(s), associated with key kGetCastingDataSucceeded
 * and matchId associated with key kGetCastingDataSucceededMatchId
 */
+(void)getCastingData:(NSInteger)matchId;

extern NSString* const kGetStatMatchDataSucceeded;
extern NSString* const kGetStatMatchDataSucceededMatchId;
extern NSString* const kGetStatMatchDataFailed;

/**
 * Get statistics data of a match.
 * Post notification with name kGetStatMatchDataSucceeded/kGetStatMatchDataFailed when succeeded or failed.
 * If succeeded, notification data contains an array of FIStatMatchItemData(s), associated with key kGetStatMatchDataSucceeded
 * and matchId associated with key kGetStatMatchDataSucceededMatchId
 */
+(void)getStatMatchData:(NSInteger)matchId;

extern NSString* const kGetTeamDataFULLSucceeded;
extern NSString* const kGetTeamDataFULLFailed;

/**
 * Get team data.
 * Post notification with name kGetTeamDataFULLSucceeded/kGetTeamDataFULLFailed when succeeded or failed.
 * If succeeded, notification data contains an FITeamData, associated with key kGetTeamDataFULLSucceeded
 * NOTE: Only get play NAME, ID and AVATARURL here.
 */
+(void)getTeamDataFull:(NSInteger)teamId;


extern NSString* const kGetPlayerDataFULLSucceeded;
extern NSString* const kGetPlayerDataFULLFailed;

/**
 * Get player data full.
 * Post notification with name kGetPlayerDataFULLSucceeded/kGetPlayerDataFULLFailed when succeeded or failed.
 * If succeeded, notification data contains an FIPlayerData, associated with key kGetPlayerDataFULLSucceeded
 */
+(void)getPlayerDataFull:(NSInteger)playerId;


extern NSString* const kGetLineUpMatchDataSucceeded;
extern NSString* const kGetLineUpMatchDataFailed;

/**
 * Get line up data of a match.
 * Post notification with name kGetLineUpMatchDataSucceeded/kGetLineUpMatchDataFailed when succeeded or failed.
 * If succeeded, notification data contains an array of FILineupData(s), associated with key kGetLineUpMatchDataSucceeded
 */
+(void)getLineUpMatchData:(NSInteger)matchId;

@end
