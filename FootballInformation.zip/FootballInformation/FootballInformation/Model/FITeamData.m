//
//  FITeamData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FITeamData.h"

@implementation FITeamData

-(NSString*)description {
    return [NSString stringWithFormat:@"{rankFIFA = %ld, teamId = %ld, name = %@, avatarURL = %@, manager = %@, player = %@}", (long)self.rankFIFA, (long)self.teamid, self.name, self.avatarURL, self.manager, self.players];
}

@end
