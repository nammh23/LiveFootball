//
//  FILineupData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FILineupData.h"

@implementation FILineupData
-(instancetype)init {
    self = [super init];
    if (self) {
        _homeLineUp = [[NSMutableArray alloc] init];
        _awayLineUp = [[NSMutableArray alloc] init];
        _homeSubs = [[NSMutableArray alloc] init];
        _awaySubs = [[NSMutableArray alloc] init];
    }
    return self;
}

-(NSString*)description {
    return [NSString stringWithFormat:@"[matchId = %ld, homeId = %ld, awayId = %ld, homeLineUp = %@, awayLineUp = %@, homeSubs = %@, awaySubs = %@]", (long)self.matchId, (long)self.homeId, (long)self.awayId, self.homeLineUp, self.awayLineUp, self.homeSubs, self.awaySubs];
}


@end
