//
//  FITableTeamData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FITableTeamData : NSObject
@property (strong, nonatomic) NSString* groupName;
@property (nonatomic) NSInteger teamID;
@property (nonatomic) NSInteger rank;
@property (nonatomic) NSInteger matchCount;
@property (nonatomic) NSInteger matchLose;
@property (nonatomic) NSInteger matchDraw;
@property (nonatomic) NSInteger matchWin;
@property (nonatomic) NSInteger goalScored;
@property (nonatomic) NSInteger goalConceded;
@property (nonatomic) NSInteger point;

///Compare to another team by rank
-(NSComparisonResult)compareRank:(FITableTeamData*)rhs;
-(NSComparisonResult)comparePointAndGoal:(FITableTeamData*)rhs;

@end
