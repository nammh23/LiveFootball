//
//  FIPlayerData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FIPlayerData : NSObject
@property (nonatomic) NSInteger playerId;
@property (strong, nonatomic) NSString* height;
@property (strong, nonatomic) NSString* club;
@property (strong, nonatomic) NSString* weight;
@property (strong, nonatomic) NSString* number;
@property (strong, nonatomic) NSString* position;
@property (strong, nonatomic) NSString* name;
@property (strong, nonatomic) NSString* placeOfBirth;
@property (strong, nonatomic) NSString* nationality;
@property (strong, nonatomic) NSString* dateOfBirth;
@property (strong, nonatomic) NSString* avatarURL;

///Set data from another player
-(void)setData:(FIPlayerData*)player;
@end
