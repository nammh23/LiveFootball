//
//  FICastingData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FICastingData : NSObject
@property (nonatomic) NSInteger tag;
@property (strong, nonatomic) NSString* time;
@property (strong, nonatomic) NSString* score;
@property (strong, nonatomic) NSString* info;

@end
