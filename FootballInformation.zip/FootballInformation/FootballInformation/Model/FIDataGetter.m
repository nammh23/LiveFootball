//
//  FIDataGetter.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//


#import "FIDataGetter.h"
#import "FITeamData.h"
#import "AFNetworking.h"
#import "FIUtil.h"
#import "FIScheduleMatchData.h"
#import "FITableTeamData.h"
#import "FICastingData.h"
#import "FIStatMatchItemData.h"
#import "FILineupData.h"
@interface FIDataGetter()
@property (nonatomic, retain) NSMutableArray* teams; //for Team data
@end

@implementation FIDataGetter
@synthesize teams = _teams;
NSString* const DEFAULT_METHOD = @"GET";
NSString* const FOOTBALLAPI_KEY = @"Authorization=565ec012251f932ea400000103bdc874acab4e4b6e5265f5231d668e";

NSString* const API_URL = @"http://api.football-api.com/2.0/";
NSString* const BASE_URL = @"http://api.football-data.org/v1/";
NSString* const TEAM_URL = @"team";
NSString* const SCHEDULE_URL = @"schedule";
NSString* const TABLE_URL = @"allstanding";
NSString* const MATCH_URL = @"matchs";
NSString* const MATCH_CASTING_URL = @"casting";
NSString* const MATCH_STAT_URL = @"stat";
NSString* const PLAYER_URL = @"player";


#pragma mark - Team list
NSString* const kGetTeamDataSucceeded = @"kGetTeamDataSucceeded";
NSString* const kGetTeamDataFailed = @"kGetTeamDataFailed";
+(void)getTeamData {
    //English Premier League team
    @try {
        NSMutableArray* dataArray = [[NSMutableArray alloc] init];
        NSArray* paths = @[@"http://api.football-api.com/2.0/standings/1204?Authorization=565ec012251f932ea400000103bdc874acab4e4b6e5265f5231d668e",@"http://api.football-api.com/2.0/standings/1415?Authorization=565ec012251f932ea400000103bdc874acab4e4b6e5265f5231d668e",@"http://api.football-api.com/2.0/standings/1229?Authorization=565ec012251f932ea400000103bdc874acab4e4b6e5265f5231d668e",@"http://api.football-api.com/2.0/standings/1399?Authorization=565ec012251f932ea400000103bdc874acab4e4b6e5265f5231d668e"];
        for(NSString* path in paths){
            NSURLRequest* theRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:path]
                                                        cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                    timeoutInterval:60.0];
            NSURLResponse *response = nil;
            NSError *error = nil;
            NSData* _connectionData = [NSURLConnection sendSynchronousRequest:theRequest returningResponse:&response error:&error];
            if (nil != error){
                NSLog(@"Error: %@", error);
            }else{
                NSString* dataString = [[NSString alloc] initWithData:_connectionData encoding:NSUTF8StringEncoding];
                [dataArray addObject:dataString];
            }
        }
        [FIDataGetter parseTeamData:dataArray];        
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  team data: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, exception.description);
    }
    
}

NSString* const TEAM_KEY_RANK = @"position";
NSString* const TEAM_KEY_TEAM_ID = @"team_id";
NSString* const TEAM_KEY_NAME = @"team_name";
NSString* const TEAM_KEY_AVATAR_URL = @"avatar";
+(void)parseTeamData:(NSMutableArray*)dataArray {
    @try {
        NSMutableArray *teams = [[NSMutableArray alloc] init];
        for(NSString* data in dataArray){
            NSArray* teamJSONs = [NSJSONSerialization JSONObjectWithData:[data dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
            //NSLog(@"TEAMCHECKKKKKKK   %@",data);

            for (int i = 0; i < [teamJSONs count]; i++) {
                FITeamData *team = [[FITeamData alloc] init];
                NSDictionary* dict = [teamJSONs objectAtIndex:i];
                team.rankFIFA = [[dict objectForKey:TEAM_KEY_RANK] integerValue];
                team.teamid = [[dict objectForKey:TEAM_KEY_TEAM_ID] integerValue];
                team.name = [dict objectForKey:TEAM_KEY_NAME];
                switch ([[dict objectForKey:@"comp_id"] integerValue]) {
                    case 1204:
                        team.avatarURL = @"http://bongdaso.com/img/Country/ENG.gif";
                        break;
                    case 1229:
                        team.avatarURL = @"http://bongdaso.com/img/Country/GER.gif";
                        break;
                    case 1399:
                        team.avatarURL = @"http://bongdaso.com/img/Country/ESP.gif";
                        break;
                    case 1415:
                        team.avatarURL = @"http://bongdaso.com/img/Country/THA.gif";
                        break;
                        
                    default:
                        break;
                }
                [teams addObject:team];
            }
        }
        //NSLog(@"TEAMSSSSS %@",teams);
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:teams, kGetTeamDataSucceeded, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetTeamDataSucceeded object:nil userInfo:userInfo];
        });
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  team data: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, exception.description);
    }
}

#pragma mark - Schedule
NSString* const kGetScheduleDataSucceeded = @"kGetScheduleDataSucceeded";
NSString* const kGetScheduleDataFailed = @"kGetScheduleDataFailed";
+(void)getScheduleData {
    @try {
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        NSDate *toDate = [[NSDate date] dateByAddingTimeInterval:60*60*24*7];

        NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
        NSString* basicPath = @"http://api.football-api.com/2.0/matches?";
        NSString* path = [NSString stringWithFormat:@"%@%@%@%@%@",basicPath,/*[dateFormatter stringFromDate:[NSDate date]]*/@"from_date=2016-01-01&to_date=",[dateFormatter stringFromDate:toDate],@"&",FOOTBALLAPI_KEY];
        AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:path]];
        NSMutableURLRequest *request = [httpClient requestWithMethod:DEFAULT_METHOD
                                                                path:@""
                                                          parameters:nil];
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [FIDataGetter parseScheduleData:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]];
            NSLog(@"<%@:%@:%d>: Load  schedule data SUCCEED", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__);
            NSLog(@"%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:kGetScheduleDataFailed object:nil userInfo:nil];
            });
            NSLog(@"<%@:%@:%d>: Load  schedule data FAILED: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, error.description);
        }];
        
        [operation start];
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  schedule data: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, exception.description);
    }
}

NSString* const SCHEDULE_MATCH_KEY_TABLE = @"comp_id";
NSString* const SCHEDULE_MATCH_KEY_TABLE_DATA = @"data";
NSString* const SCHEDULE_MATCH_KEY_TIMESTAMP = @"formatted_date";
NSString* const SCHEDULE_MATCH_KEY_TIME = @"time";
NSString* const SCHEDULE_MATCH_KEY_RESULT = @"result";
NSString* const SCHEDULE_MATCH_KEY_MATCH_ID = @"id";
NSString* const SCHEDULE_MATCH_KEY_STATUS = @"status";
NSString* const SCHEDULE_MATCH_KEY_AWAY_NAME = @"visitorteam_name";
NSString* const SCHEDULE_MATCH_KEY_HOME_NAME = @"localteam_name";
NSString* const SCHEDULE_MATCH_KEY_AWAY_ID = @"visitorteam_id";
NSString* const SCHEDULE_MATCH_KEY_HOME_ID = @"localteam_id";
NSString* const SCHEDULE_MATCH_KEY_AWAY_SCORE = @"visitorteam_score";
NSString* const SCHEDULE_MATCH_KEY_HOME_SCORE = @"localteam_score";

NSString* const SCHEDULE_MATCH_RESULT_SEPARATOR = @":";
+(void)parseScheduleData:(NSString*)responseData {
    @try {
        NSArray* data = [NSJSONSerialization JSONObjectWithData:[responseData dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        NSMutableArray *matches = [[NSMutableArray alloc] init];
        NSDictionary* groupMatch = [[NSDictionary alloc] init];
        for (int i = 0; i < [data count]; i++) {
            groupMatch = [data objectAtIndex:i]; //dictionary of data of a group
           // NSDictionary* eventMatch = [groupMatch valueForKey:@"events"];
            FIScheduleMatchData *matchInfo = [[FIScheduleMatchData alloc] init];
            matchInfo.group = [groupMatch valueForKey:SCHEDULE_MATCH_KEY_TABLE];
            NSString* getDate = [NSString stringWithFormat:@"%@ %@",[groupMatch valueForKey:SCHEDULE_MATCH_KEY_TIMESTAMP],[groupMatch valueForKey:SCHEDULE_MATCH_KEY_TIME]];
            NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
            [dateFormat setDateFormat:@"dd.MM.yyyy HH:mm"];
            matchInfo.date= [dateFormat dateFromString:getDate];
            matchInfo.matchID = [[groupMatch valueForKey:SCHEDULE_MATCH_KEY_MATCH_ID] integerValue];
            matchInfo.status = [groupMatch valueForKey:SCHEDULE_MATCH_KEY_STATUS];
            matchInfo.awayName = [groupMatch valueForKey:SCHEDULE_MATCH_KEY_AWAY_NAME];
            matchInfo.homeName = [groupMatch valueForKey:SCHEDULE_MATCH_KEY_HOME_NAME];
            matchInfo.awayId = [[groupMatch valueForKey:SCHEDULE_MATCH_KEY_AWAY_ID] integerValue];
            matchInfo.homeId = [[groupMatch valueForKey:SCHEDULE_MATCH_KEY_HOME_ID] integerValue];
            matchInfo.awayScore = [[groupMatch valueForKey:SCHEDULE_MATCH_KEY_AWAY_SCORE] integerValue];
            matchInfo.homeScore = [[groupMatch valueForKey:SCHEDULE_MATCH_KEY_HOME_SCORE] integerValue];
            matchInfo.started = YES;
            [matches addObject:matchInfo];
        }

        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:matches, kGetScheduleDataSucceeded, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetScheduleDataSucceeded object:nil userInfo:userInfo];
        });
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  schedule data: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, exception.description);
    }
}

#pragma mark - Table
NSString* const kGetTableDataSucceeded = @"kGetTableDataSucceeded";
NSString* const kGetTableDataFailed = @"kGetTableDataFailed";

+(void)getTableData:(NSInteger)leagueID {
    @try {
        NSString* basicURL = [NSString stringWithFormat:@"%@%ld%@",@"http://api.football-api.com/2.0/standings/",(long)leagueID,@"?Authorization=565ec012251f932ea400000103bdc874acab4e4b6e5265f5231d668e"];
        AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:basicURL]];
        NSMutableURLRequest *request = [httpClient requestWithMethod:DEFAULT_METHOD
                                                                path:@""
                                                          parameters:nil];
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [FIDataGetter parseTableData:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding] forLeague:leagueID];
            
            NSLog(@"<%@:%@:%d>: Load  table data SUCCEED", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:kGetTableDataFailed object:nil userInfo:nil];
            });
            NSLog(@"<%@:%@:%d>: Load  table data FAILED: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, error.description);
        }];
        
        [operation start];
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  table data: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, exception.description);
    }
}

NSString* const TABLE_KEY_GROUPNAME = @"comp_id";
NSString* const TABLE_KEY_DATA = @"data";
NSString* const TABLE_KEY_GOAL_AGAINT = @"overall_ga";
NSString* const TABLE_KEY_RANK = @"position";
NSString* const TABLE_KEY_MATCH_LOSE = @"overall_l";
NSString* const TABLE_KEY_GOAL_SCORED = @"overall_gs";
NSString* const TABLE_KEY_MATCH_DRAW = @"overall_d";
NSString* const TABLE_KEY_MATCH_COUNT = @"overall_gp";
NSString* const TABLE_KEY_TEAM_ID = @"team_id";
NSString* const TABLE_KEY_POINT = @"points";
NSString* const TABLE_KEY_MATCH_WIN = @"overall_w";
+(void)parseTableData:(NSString*)data forLeague:(NSInteger)leagueID{
    @try {
        NSArray* tableJSONs = [NSJSONSerialization JSONObjectWithData:[data dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        NSMutableArray *teams = [[NSMutableArray alloc] init];
        for (int i = 0; i < [tableJSONs count]; i++) {
            NSDictionary* groupDict = [tableJSONs objectAtIndex:i]; //dictionary of data of a group
            FITableTeamData *team = [[FITableTeamData alloc] init];
            team.groupName = [groupDict objectForKey:TABLE_KEY_GROUPNAME];
            team.goalConceded = [[groupDict objectForKey:TABLE_KEY_GOAL_AGAINT] integerValue];
            team.rank = [[groupDict objectForKey:TABLE_KEY_RANK] integerValue];
            team.matchLose = [[groupDict objectForKey:TABLE_KEY_MATCH_LOSE] integerValue];
            team.goalScored = [[groupDict objectForKey:TABLE_KEY_GOAL_SCORED] integerValue];
            team.matchDraw = [[groupDict objectForKey:TABLE_KEY_MATCH_DRAW] integerValue];
            team.matchCount = [[groupDict objectForKey:TABLE_KEY_MATCH_COUNT] integerValue];
            team.teamID = [[groupDict objectForKey:TABLE_KEY_TEAM_ID] integerValue];
            team.point = [[groupDict objectForKey:TABLE_KEY_POINT] integerValue];
            team.matchWin = [[groupDict objectForKey:TABLE_KEY_MATCH_WIN] integerValue];
            [teams addObject:team];
        }
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:teams, kGetTableDataSucceeded, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetTableDataSucceeded object:nil userInfo:userInfo];
        });
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  table data: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, exception.description);
    }
}

#pragma mark - Casting
const int TEST_MATCH_ID = 19751;

NSString* const kGetCastingDataSucceeded = @"kGetCastingDataSucceeded";
NSString* const kGetCastingDataSucceededMatchId = @"kGetCastingDataSucceededMatchId";
NSString* const kGetCastingDataFailed = @"kGetCastingDataFailed";

+(void)getCastingData:(NSInteger)matchId {
    @try {
        NSString* basicPath = @"http://api.football-api.com/2.0/matches?match_date=";
        NSString* path = [NSString stringWithFormat:@"%@%@%@%@",basicPath,/*[dateFormatter stringFromDate:[NSDate date]]*/@"2016-05-17",@"&",FOOTBALLAPI_KEY];
        AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:path]];
        //NSString* path = [NSString stringWithFormat:@"%@/%ld/%@", MATCH_URL, (long)matchId, MATCH_CASTING_URL];
        NSMutableURLRequest *request = [httpClient requestWithMethod:DEFAULT_METHOD
                                                                path:@""
                                                          parameters:nil];
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [FIDataGetter parseCastingData:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding] forMatch:matchId];
            NSLog(@"<%@:%@:%d>: Load  casting data for match %ld SUCCEED", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:kGetCastingDataFailed object:nil userInfo:nil];
            });
            NSLog(@"<%@:%@:%d>: Load  casting data for match %ld FAILED: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, error.description);
        }];
        
        [operation start];
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  casting data for match %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, exception.description);
    }
}

NSString* const CASTING_KEY_TIME = @"minute";
NSString* const CASTING_KEY_SCORE = @"result";
NSString* const CASTING_KEY_TYPE = @"type";
NSString* const CASTING_KEY_PLAYER = @"player";
NSString* const CASTING_KEY_ASSIST = @"assist";
+(void)parseCastingData:(NSString*)responseData forMatch:(NSInteger)matchId{
    @try {
        NSArray* data = [NSJSONSerialization JSONObjectWithData:[responseData dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        NSDictionary* groupMatch = [[NSDictionary alloc] init];
        NSArray* eventMatch = [[NSArray alloc] init];
        NSMutableArray* castings = [[NSMutableArray alloc] init];

        //FIScheduleMatchData *matchInfo = [[FIScheduleMatchData alloc] init];
        //matchInfo.group = [groupMatch valueForKey:SCHEDULE_MATCH_KEY_TABLE];
        for (int i = 0; i < [data count]; i++) {
            groupMatch = [data objectAtIndex:i]; //dictionary of data of a group
            //NSLog(@"MATCHIDDDDDDD %ld",[[groupMatch valueForKey:SCHEDULE_MATCH_KEY_MATCH_ID] integerValue] );
            if([[groupMatch valueForKey:SCHEDULE_MATCH_KEY_MATCH_ID] integerValue] == matchId){
                eventMatch = [groupMatch valueForKey:@"events"];
                NSLog(@"EVENTMATCH   %@",eventMatch);
                for(int j = 0 ; j < [eventMatch count]; j++){
                    NSDictionary* event = [eventMatch objectAtIndex:j];
                    FICastingData *dataCasting = [[FICastingData alloc] init];
                    dataCasting.time = [event valueForKey:CASTING_KEY_TIME];
                    dataCasting.score = [event valueForKey:CASTING_KEY_SCORE];
                    dataCasting.info = [NSString stringWithFormat:@"%@%@%@",[event valueForKey:CASTING_KEY_TYPE ],@" : ", [event valueForKey:CASTING_KEY_PLAYER]];
                    [castings addObject:dataCasting];
                }
            }
        }
        //NSLog(@"CASTINGGGGGGG   %@",castings);
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:castings, kGetCastingDataSucceeded, [NSString stringWithFormat:@"%ld", (long)matchId], kGetCastingDataSucceededMatchId, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetCastingDataSucceeded object:nil userInfo:userInfo];
        });
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  casting data for match %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, exception.description);
    }
}

#pragma mark - Match Stat
NSString* const kGetStatMatchDataSucceeded = @"kGetStatMatchDataSucceeded";
NSString* const kGetStatMatchDataSucceededMatchId = @"kGetStatMatchDataSucceededMatchId";
NSString* const kGetStatMatchDataFailed = @"kGetStatMatchDataFailed";

+(void)getStatMatchData:(NSInteger)matchId {
    @try {
        //        matchId = TEST_MATCH_ID;
        
        AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:BASE_URL]];
        NSString* path = [NSString stringWithFormat:@"%@/%ld/%@", MATCH_URL, (long)matchId, MATCH_STAT_URL];
        NSMutableURLRequest *request = [httpClient requestWithMethod:DEFAULT_METHOD
                                                                path:path
                                                          parameters:nil];
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [FIDataGetter parseStatMatchData:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding] forMatch:matchId];
            NSLog(@"<%@:%@:%d>: Load  StatMatch data for match %ld SUCCEED", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:kGetStatMatchDataFailed object:nil userInfo:nil];
            });
            NSLog(@"<%@:%@:%d>: Load  StatMatch data for match %ld FAILED: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, error.description);
        }];
        
        [operation start];
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  StatMatch data for match %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, exception.description);
    }
}

NSString* const MATCH_STAT_KEY_HOME = @"home";
NSString* const MATCH_STAT_KEY_AWAY = @"away";
+(void)parseStatMatchData:(NSString*)data forMatch:(NSInteger)matchId{
    @try {
        NSDictionary* fullDict = [NSJSONSerialization JSONObjectWithData:[data dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        

    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  StatMatch data for match %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, exception.description);
    }
}

#pragma mark - Team info
NSString* const kGetTeamDataFULLSucceeded = @"kGetTeamDataFULLSucceeded";
NSString* const kGetTeamDataFULLFailed = @"kGetTeamDataFULLFailed";

+(void)getTeamDataFull:(NSInteger)teamId {
    @try {
        NSString* basicURL = @"http://api.football-api.com/2.0/team";
        AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:basicURL]];
        NSString* path = [NSString stringWithFormat:@"%ld?%@", (long)teamId,FOOTBALLAPI_KEY];
        NSMutableURLRequest *request = [httpClient requestWithMethod:DEFAULT_METHOD
                                                                path:path
                                                          parameters:nil];
        //NSLog(@"REQUESTTTTTTTT %@",request);
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [FIDataGetter parseTeamDataFULL:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding] forTeam:teamId];
            
            NSLog(@"<%@:%@:%d>: Load  team data FULL for team %ld SUCCEED", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)teamId);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:kGetTeamDataFULLFailed object:nil userInfo:nil];
            });
            NSLog(@"<%@:%@:%d>: Load  team data FULL for team %ld FAILED: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)teamId, error.description);
        }];
        
        [operation start];
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  team data FULL for team %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)teamId, exception.description);
    }
}

NSString* const TEAM_FULL_KEY_MANAGER = @"coach_name";
NSString* const TEAM_FULL_KEY_PLAYERS = @"squad";
NSString* const TEAM_FULL_KEY_PLAYER_ID = @"id";
NSString* const TEAM_FULL_KEY_PLAYER_NAME = @"name";
NSString* const TEAM_FULL_KEY_PLAYER_AVATAR_URL = @"avatar";

+(void)parseTeamDataFULL:(NSString*)data forTeam:(NSInteger)teamId {
    @try {
        NSDictionary* teamDict = [NSJSONSerialization JSONObjectWithData:[data dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        FITeamData *team = [[FITeamData alloc] init];
        NSArray *stat = [teamDict objectForKey:@"statistics"];
        team.rankFIFA = [[[stat objectAtIndex:0] objectForKey:@"rank"] integerValue];
        team.teamid = teamId;
        team.name = [teamDict objectForKey:@"name"];
        NSString* country = [teamDict objectForKey:@"country"];
        if([country isEqualToString:@"England"]){
            team.avatarURL = @"http://bongdaso.com/img/Country/ENG.gif";
        }else if([country isEqualToString:@"Germany"]){
            team.avatarURL = @"http://bongdaso.com/img/Country/GER.gif";
        }else if([country isEqualToString:@"Spain"]){
            team.avatarURL = @"http://bongdaso.com/img/Country/GER.gif";
        }else if([country isEqualToString:@"Thailand"]){
            team.avatarURL = @"http://bongdaso.com/img/Country/GER.gif";
        }
        
        team.manager = [teamDict objectForKey:TEAM_FULL_KEY_MANAGER];
        
        NSArray* playerInfos = [teamDict objectForKey:TEAM_FULL_KEY_PLAYERS];
        NSMutableArray* players = [[NSMutableArray alloc] init];
        for (int i = 0; i < [playerInfos count]; i++) {
            NSDictionary* playerDict = [playerInfos objectAtIndex:i];
            
            FIPlayerData* player = [[FIPlayerData alloc] init];
            player.name = [playerDict objectForKey:TEAM_FULL_KEY_PLAYER_NAME];
            player.playerId = [[playerDict objectForKey:TEAM_FULL_KEY_PLAYER_ID] integerValue];
            player.avatarURL = @"http://bongdaso.com/_Image.aspx?Cat=Player&ID=338";//[playerDict objectForKey:TEAM_FULL_KEY_PLAYER_AVATAR_URL];
            
            [players addObject:player];
        }
        team.players = players;
        NSLog(@"TEAMMMMMMMFFJJF %@",team);
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:team, kGetTeamDataFULLSucceeded, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetTeamDataFULLSucceeded object:nil userInfo:userInfo];
        });
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  team data FULL for team %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__,(long)teamId, exception.description);
    }
}

#pragma mark - Player
NSString* const kGetPlayerDataFULLSucceeded = @"kGetPlayerDataFULLSucceeded";
NSString* const kGetPlayerDataFULLFailed = @"kGetPlayerDataFULLFailed";

+(void)getPlayerDataFull:(NSInteger)playerId {
    @try {
        NSString* basicURL = @"http://api.football-api.com/2.0/player";
        AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:basicURL]];
        NSString* path = [NSString stringWithFormat:@"%ld?%@", playerId,FOOTBALLAPI_KEY];
        NSMutableURLRequest *request = [httpClient requestWithMethod:DEFAULT_METHOD
                                                                path:path
                                                          parameters:nil];
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [FIDataGetter parsePlayerDataFULL:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding] forPlayer:playerId];
            NSLog(@"<%@:%@:%d>: Load  player data FULL for player %ld SUCCEED", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)playerId);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:kGetPlayerDataFULLFailed object:nil userInfo:nil];
            });
            NSLog(@"<%@:%@:%d>: Load  player data FULL for player %ld FAILED: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)playerId, error.description);
        }];
        
        [operation start];
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  player data FULL for player %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)playerId, exception.description);
    }
}

NSString* const PLAYER_FULL_KEY_DATA = @"data";
NSString* const PLAYER_FULL_KEY_HEIGHT = @"height";
NSString* const PLAYER_FULL_KEY_CLUB = @"team";
NSString* const PLAYER_FULL_KEY_WEIGHT = @"weight";
NSString* const PLAYER_FULL_KEY_NUMBER = @"id";//shirt number
NSString* const PLAYER_FULL_KEY_POSITION = @"position";
NSString* const PLAYER_FULL_KEY_NAME = @"name";
NSString* const PLAYER_FULL_KEY_BP = @"birthplace";
NSString* const PLAYER_FULL_KEY_POB = @"birthcountry";
NSString* const PLAYER_FULL_KEY_NATIONALITY = @"nationality";
NSString* const PLAYER_FULL_KEY_DOB = @"birthdate";
NSString* const PLAYER_FULL_KEY_AVATAR_URL = @"avatar";

+(void)parsePlayerDataFULL:(NSString*)data forPlayer:(NSInteger)playerId {
    @try {
        NSDictionary* dict = [NSJSONSerialization JSONObjectWithData:[data dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        //NSLog(@"PLAYERRRRRRRRR%@",playerDataDict);
        //NSDictionary* dict = [playerDataDict objectForKey:PLAYER_FULL_KEY_DATA];
        
        FIPlayerData *player = [[FIPlayerData alloc] init];
        player.playerId = playerId;
        player.height = [dict objectForKey:PLAYER_FULL_KEY_HEIGHT];
        player.club = [dict objectForKey:PLAYER_FULL_KEY_CLUB];
        player.weight = [dict objectForKey:PLAYER_FULL_KEY_WEIGHT];
        player.number = [dict objectForKey:PLAYER_FULL_KEY_NUMBER];
        player.position = [dict objectForKey:PLAYER_FULL_KEY_POSITION];
        player.name = [dict objectForKey:PLAYER_FULL_KEY_NAME];
        player.placeOfBirth = [NSString stringWithFormat:@"%@ %@",[dict objectForKey:PLAYER_FULL_KEY_BP],[dict objectForKey:PLAYER_FULL_KEY_POB]];
        player.nationality = [dict objectForKey:PLAYER_FULL_KEY_NATIONALITY];
        player.dateOfBirth = [dict objectForKey:PLAYER_FULL_KEY_DOB];
        player.avatarURL = @"http://bongdaso.com/_Image.aspx?Cat=Player&ID=338";;//[dict objectForKey:PLAYER_FULL_KEY_AVATAR_URL];
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:player, kGetPlayerDataFULLSucceeded, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetPlayerDataFULLSucceeded object:nil userInfo:userInfo];
        });
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  player data FULL for player %d: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__,playerId, exception.description);
    }
}


#pragma mark - Line Up
NSString* const kGetLineUpMatchDataSucceeded = @"kGetLineUpMatchDataSucceeded";
NSString* const kGetLineUpMatchDataFailed = @"kGetLineUpMatchDataFailed";

+(void)getLineUpMatchData:(NSInteger)matchId {
    @try {
        //        matchId = TEST_MATCH_ID;
        NSString* basicURL = @"http://api.football-api.com/2.0/commentaries";
        AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:basicURL]];
        NSString* path = [NSString stringWithFormat:@"%ld?%@", (long)matchId,FOOTBALLAPI_KEY];
        NSMutableURLRequest *request = [httpClient requestWithMethod:DEFAULT_METHOD
                                                                path:path
                                                          parameters:nil];
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [FIDataGetter parseLineUpMatchData:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding] forMatch:matchId];
            NSLog(@"<%@:%@:%d>: Load  line up data for match %ld SUCCEED", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:kGetLineUpMatchDataFailed object:nil userInfo:nil];
            });
            NSLog(@"<%@:%@:%d>: Load  line up data for match %ld FAILED: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, error.description);
        }];
        
        [operation start];
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to get  line up data for match %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, exception.description);
    }
}

NSString* const MATCH_LINEUP_KEY_HOME_ID = @"localteam";
NSString* const MATCH_LINEUP_KEY_AWAY_ID = @"visitorteam";
NSString* const MATCH_LINEUP_KEY_HOME_LINEUP = @"home_Lineup";
NSString* const MATCH_LINEUP_KEY_AWAY_LINEUP = @"away_Lineup";
NSString* const MATCH_LINEUP_KEY_LINEUP = @"lineup";
NSString* const MATCH_LINEUP_KEY_SUBS = @"subs";
NSString* const MATCH_LINEUP_KEY_PLAYER_ID = @"id";
NSString* const MATCH_LINEUP_KEY_PLAYER_NAME = @"name";

+(void)parseLineUpMatchData:(NSString*)data forMatch:(NSInteger)matchId{
    @try {
        
        NSDictionary* fullDict = [NSJSONSerialization JSONObjectWithData:[data dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        
        FILineupData* lineup = [[FILineupData alloc] init];
        lineup.matchId = matchId;
        lineup.homeId = 9260;//[[fullDict objectForKey:MATCH_LINEUP_KEY_HOME_ID] integerValue];
        lineup.awayId = 9053;//[[fullDict objectForKey:MATCH_LINEUP_KEY_AWAY_ID] integerValue];
        NSDictionary* lineupData = [fullDict objectForKey:MATCH_LINEUP_KEY_LINEUP];
        NSDictionary* subData = [fullDict objectForKey:MATCH_LINEUP_KEY_SUBS];
        
        //home line up
        NSArray* homeSub = [subData objectForKey:MATCH_LINEUP_KEY_HOME_ID];
        for (int i = 0; i < [homeSub count]; i++) {
            NSDictionary* playerDict = [homeSub objectAtIndex:i];
            
            FIPlayerData* player = [[FIPlayerData alloc] init];
            player.playerId = [[playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_ID] integerValue];
            player.name = [playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_NAME];
            
            [lineup.homeSubs addObject:player];
        }
        
        NSArray* homelineup = [lineupData objectForKey:MATCH_LINEUP_KEY_HOME_ID];
        for (int i = 0; i < [homelineup count]; i++) {
            NSDictionary* playerDict = [homelineup objectAtIndex:i];
            
            FIPlayerData* player = [[FIPlayerData alloc] init];
            player.playerId = [[playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_ID] integerValue];
            player.name = [playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_NAME];
            
            [lineup.homeLineUp addObject:player];
        }
        
        
        //away lineup
        
        NSArray* awaySub = [subData objectForKey:MATCH_LINEUP_KEY_AWAY_ID];
        for (int i = 0; i < [awaySub count]; i++) {
            NSDictionary* playerDict = [awaySub objectAtIndex:i];
            
            FIPlayerData* player = [[FIPlayerData alloc] init];
            player.playerId = [[playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_ID] integerValue];
            player.name = [playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_NAME];
            
            [lineup.awaySubs addObject:player];
        }
        
        NSArray* awaylineup = [lineupData objectForKey:MATCH_LINEUP_KEY_AWAY_ID];
        for (int i = 0; i < [awaylineup count]; i++) {
            NSDictionary* playerDict = [awaylineup objectAtIndex:i];
            
            FIPlayerData* player = [[FIPlayerData alloc] init];
            player.playerId = [[playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_ID] integerValue];
            player.name = [playerDict objectForKey:MATCH_LINEUP_KEY_PLAYER_NAME];
            
            [lineup.awayLineUp addObject:player];
        }
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:lineup, kGetLineUpMatchDataSucceeded, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetLineUpMatchDataSucceeded object:nil userInfo:userInfo];
        });
    }
    @catch (NSException *exception) {
        NSLog(@"<%@:%@:%d>: unable to parse  line up data for match %ld: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, (long)matchId, exception.description);
    }
}


@end
