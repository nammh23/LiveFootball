//
//  FILeagueInformation.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/19/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FILeagueInformation : NSObject
@property (nonatomic) NSInteger leagueID;
@property (strong, nonatomic) NSString* leagueName;
@property (strong, nonatomic) NSString* avatarURL;

@property (strong, nonatomic) NSString* region;
@end
