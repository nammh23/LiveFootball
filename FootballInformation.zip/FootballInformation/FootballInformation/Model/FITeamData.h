//
//  FITeamData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FIPlayerData.h"

@interface FITeamData : NSObject

@property (nonatomic) NSInteger rankFIFA;
@property (nonatomic) NSInteger teamid;
@property (strong, nonatomic) NSString* name;
@property (strong, nonatomic) NSString* avatarURL;

@property (strong, nonatomic) NSString* manager;
@property (strong, nonatomic) NSMutableArray* players; //of FIPlayerData
@end
