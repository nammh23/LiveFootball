//
//  FIStatMatchItemData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FIStatMatchItemData.h"

@implementation FIStatMatchItemData
-(NSString*)description {
    return [NSString stringWithFormat:@"[name = %@, homeValue = %@, awayValue = %@]", self.name, self.homeValue, self.awayValue];
}
@end
