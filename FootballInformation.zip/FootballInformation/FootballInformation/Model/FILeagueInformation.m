//
//  FILeagueInformation.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/19/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FILeagueInformation.h"

@implementation FILeagueInformation
-(NSString*)description {
    return [NSString stringWithFormat:@"{LeagueID = %ld, name = %@, avatarURL = %@, Region = %@}", (long)self.leagueID, self.leagueName, self.avatarURL, self.region];
}

@end
