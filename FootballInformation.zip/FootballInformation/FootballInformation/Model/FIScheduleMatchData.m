//
//  FIScheduleData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FIScheduleMatchData.h"

@implementation FIScheduleMatchData

-(NSString*)description {
    return [NSString stringWithFormat:@"[MatchID = %ld, group = %@, date = %@, status = %@, awayName = %@, homeName = %@, awayId = %ld, homeId = %ld, awayScore = %ld, homeScore = %ld], started = %@", (long)self.matchID, self.group, self.date, self.status, self.awayName, self.homeName, (long)self.awayId, (long)self.homeId, (long)self.awayScore, (long)self.homeScore, self.started ? @"YES" : @"NO"];
}

@end
