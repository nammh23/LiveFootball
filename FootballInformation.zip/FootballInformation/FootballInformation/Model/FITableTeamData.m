//
//  FITableTeamData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FITableTeamData.h"

@implementation FITableTeamData
-(NSString*)description {
    return [NSString stringWithFormat:@"[group = %@, id = %d, rank = %d, matchCount = %d, win = %d, draw = %d, lose = %d, goalScored = %d, goalConceded = %d, point = %d]", self.groupName, self.teamID, self.rank, self.matchCount, self.matchWin, self.matchDraw, self.matchLose, self.goalScored, self.goalConceded, self.point];
}
-(NSComparisonResult)compareRank:(FITableTeamData*)rhs {
    if (self.rank < rhs.rank) {
        return NSOrderedAscending;
    } else if (self.rank == rhs.rank) {
        return NSOrderedSame;
    } else {
        return NSOrderedDescending;
    }
}

-(NSComparisonResult)comparePointAndGoal:(FITableTeamData *)rhs {
    if (self.point < rhs.point) {
        return NSOrderedAscending;
    }
    
    if (rhs.point < self.point) {
        return NSOrderedDescending;
    }
    
    if ((self.goalScored - self.goalConceded) < (rhs.goalScored - rhs.goalConceded)) {
        return NSOrderedAscending;
    }
    
    if ((rhs.goalScored - rhs.goalConceded) < (self.goalScored - self.goalConceded)) {
        return NSOrderedDescending;
    }
    
    return NSOrderedSame;
}


@end
