//
//  FILineupData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FILineupData : NSObject
@property (nonatomic) NSInteger matchId;
@property (nonatomic) NSInteger homeId;
@property (nonatomic) NSInteger awayId;
@property (strong, nonatomic) NSMutableArray *homeLineUp; //of FIPlayerData
@property (strong, nonatomic) NSMutableArray *awayLineUp; //of FIPlayerData
@property (strong, nonatomic) NSMutableArray *homeSubs; //of FIPlayerData
@property (strong, nonatomic) NSMutableArray *awaySubs; //of FIPlayerData

@end
