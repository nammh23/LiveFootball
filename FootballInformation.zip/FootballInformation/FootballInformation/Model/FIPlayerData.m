//
//  FIPlayerData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FIPlayerData.h"

@implementation FIPlayerData

-(NSString*)description {
    return [NSString stringWithFormat:@"[id = %ld, name = %@, DOB = %@, height = %@, club = %@, weight = %@, number = %@, pos = %@, POB = %@, nation = %@, avatarURL = %@]", (long)self.playerId, self.name, self.dateOfBirth, self.height, self.club, self.weight, self.number, self.position, self.placeOfBirth, self.nationality, self.avatarURL];
}

-(void)setData:(FIPlayerData *)player {
    self.playerId = player.playerId;
    self.name = player.name;
    self.dateOfBirth = player.dateOfBirth;
    self.height = player.height;
    self.club = player.club;
    self.weight = player.weight;
    self.number = player.number;
    self.position = player.position;
    self.placeOfBirth = player.placeOfBirth;
    self.nationality = player.nationality;
    self.avatarURL = player.avatarURL;
}@end
