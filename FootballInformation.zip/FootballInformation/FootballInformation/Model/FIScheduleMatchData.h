//
//  FIScheduleData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//


#import <Foundation/Foundation.h>

#import "FIUtil.h"

@interface FIScheduleMatchData : NSObject

@property (nonatomic) NSInteger matchID;
@property (nonatomic) NSString* group;
@property (strong, nonatomic) NSDate* date;
//@property (nonatomic) MatchStatus status;
@property (nonatomic) NSString* status;
@property (strong, nonatomic) NSString* awayName;
@property (strong, nonatomic) NSString* homeName;
@property (nonatomic) NSInteger awayId;
@property (nonatomic) NSInteger homeId;
@property (nonatomic) NSInteger awayScore;
@property (nonatomic) NSInteger homeScore;
@property (nonatomic) bool started;

@end
