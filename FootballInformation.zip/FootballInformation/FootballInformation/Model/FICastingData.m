//
//  FICastingData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FICastingData.h"

@implementation FICastingData

-(NSString*)description {
    return [NSString stringWithFormat:@"[tag = %ld, time = %@, score = %@, info = %@]", (long)self.tag, self.time, self.score, self.info];
}

@end
