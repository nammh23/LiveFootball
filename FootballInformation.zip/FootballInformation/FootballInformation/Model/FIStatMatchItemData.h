//
//  FIStatMatchItemData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FIStatMatchItemData : NSObject
@property (strong, nonatomic) NSString* name;
@property (strong, nonatomic) NSString* homeValue;
@property (strong, nonatomic) NSString* awayValue;

@end
