//
//  FITableViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FITableViewController.h"
#import "FIUtil.h"
#import "FIConfig.h"
#import "FITableTableViewCell.h"
#import "FITableHeaderViewCell.h"
#import "SWRevealViewController.h"
#import "FIDataGetter.h"
#import "FITableTeamData.h"
#import "FITableGroupData.h"
#import "FITeamData.h"
#import "FITeamInfoViewController.h"


@interface FITableViewController ()

@property (strong, nonatomic) NSString* tableTableViewCellNibName;

@property (strong, nonatomic) NSString* tableTableHeaderViewCellNibName;

@property (strong, nonatomic) NSArray* teams; //of FITeamData
@property (strong, nonatomic) NSMutableArray* groups; //of FITableGroupData
@property (nonatomic) NSInteger selectedTeamId;

@property (strong, nonatomic) UIRefreshControl *refreshControl;

@end

@implementation FITableViewController
@synthesize leagueID;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.groups = [[NSMutableArray alloc] init];
    self.selectedTeamId = 0;
    
    [FIDataGetter getTeamData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataSucceeded:) name:kGetTeamDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataFailed:) name:kGetTeamDataFailed object:nil];
    
    [FIDataGetter getTableData:leagueID];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTableDataSucceeded:) name:kGetTableDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTableDataFailed:) name:kGetTeamDataFailed object:nil];
    
    //set navigation bar
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:BACKGROUND_IMAGE_NAVIGATION_BAR] forBarMetrics:UIBarMetricsDefault];
    
    NSDictionary *attributes = @{UITextAttributeTextColor: [UIColor whiteColor],
                                 UITextAttributeFont: [UIFont fontWithName:NAVIGATION_BAR_FONT_NAME size:NAVIGATION_BAR_FONT_SIZE]};
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    }
    
    //set table table
    if (IS_IPHONE) {
        self.tableTableHeaderViewCellNibName = @"FITableHeaderViewCell";
    } else {
        self.tableTableHeaderViewCellNibName = @"FITableHeaderViewCell_ipad";
    }
    
    self.tableTableView.backgroundView = nil;
    self.tableTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]];
    if ([self.tableTableView respondsToSelector:@selector(separatorInset)]) {
        [self.tableTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"6.0")) {
        self.refreshControl = [[UIRefreshControl alloc] init];
        [self.tableTableView addSubview:self.refreshControl];
        [self.refreshControl addTarget:self action:@selector(refreshTable) forControlEvents:UIControlEventValueChanged];
    }
    //fix separator issues
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.tableTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        self.tableTableView.separatorColor = [UIColor darkGrayColor];
    } else {
        self.tableTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.tableTableView.separatorColor = [UIColor blackColor];
    }
    
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)refreshTable {
    [self.refreshControl endRefreshing];
    [FIDataGetter getTableData:leagueID];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Table View Datasource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [self.groups count];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section < [self.groups count]) {
        FITableGroupData* group = [self.groups objectAtIndex:section];
        //        return [group.teams count] + 1;
        return [group.teams count];
    } else {
        return 0;
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString* cellIdentifier = @"tableTableCell";
    FITableTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[FITableTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    //selected background
    UIView *bgSelectedColorView = [[UIView alloc] init];
    bgSelectedColorView.backgroundColor = [UIColor colorWithRed:TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED green:TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN blue:TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE alpha:TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA];
    bgSelectedColorView.layer.masksToBounds = YES;
    [cell setSelectedBackgroundView:bgSelectedColorView];
    
    [cell.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    
    //data
    if (indexPath.section < [self.groups count]) {
        FITableGroupData* group = [self.groups objectAtIndex:indexPath.section];
        int teamIndex = indexPath.row;
        if (teamIndex < [group.teams count]) {
            FITableTeamData* team = [group.teams objectAtIndex:teamIndex];
            FITeamData* teamInfo = [self getTeamForId:team.teamID];
            cell.teamNameLabel.text = teamInfo.name;
            
            cell.matchCountLabel.text = [NSString stringWithFormat:@"%ld", (long)team.matchCount];
            cell.matchWinLabel.text = [NSString stringWithFormat:@"%ld", (long)team.matchWin];
            cell.matchDrawLabel.text = [NSString stringWithFormat:@"%ld", (long)team.matchDraw];
            cell.matchLoseLabel.text = [NSString stringWithFormat:@"%ld", (long)team.matchLose];
            cell.pointLabel.text = [NSString stringWithFormat:@"%ld", (long)team.point];
            cell.rankLabel.text = [NSString stringWithFormat:@"%ld", (long)(indexPath.row+1)];
            __weak FITableTableViewCell* weakCell = cell;
            NSString* avatarPath = [[FIUtil getTeamAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png", (long)teamInfo.teamid]];
            if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
                NSURL *avatarURL = [NSURL URLWithString:teamInfo.avatarURL];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                    NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        // Update the UI
                        UIImage *image = [UIImage imageWithData:imageData];
                        weakCell.logoImageView.image = image;
                        
                        //save
                        [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                    });
                });
            } else {
                cell.logoImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
            }
        }
    }
    
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    FITableHeaderViewCell *headerView = (FITableHeaderViewCell*)[[[NSBundle mainBundle] loadNibNamed:self.tableTableHeaderViewCellNibName owner:self options:nil] firstObject];
    [headerView.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    
    if (section < [self.groups count]) {
        FITableGroupData* group = [self.groups objectAtIndex:section];
        switch ([group.groupName integerValue]) {
            case 1204:
                headerView.groupNameLabel.text = @"Premier League";
                break;
            case 1229:
                headerView.groupNameLabel.text = @"Bundesliga";
                break;
            case 1399:
                headerView.groupNameLabel.text = @"La Liga-Spain";
                break;
            case 1415:
                headerView.groupNameLabel.text = @"Thai Premier League";
                break;
                
            default:
                break;
        }
    }
    return headerView;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return self.tableTableView.rowHeight;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.00001f;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return tableView.rowHeight;
}

NSString* const kTableToTeamInfoSegueIdentifier = @"tableToTeamDetail";
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section < [self.groups count]) {
        FITableGroupData* group = [self.groups objectAtIndex:indexPath.section];
        if (group) {
            if (indexPath.row < [group.teams count]) {
                FITableTeamData* team = [group.teams objectAtIndex:indexPath.row];
                self.selectedTeamId = team.teamID;
                [self performSegueWithIdentifier:kTableToTeamInfoSegueIdentifier sender:nil];
            }
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark -  data getter
-(void)getTeamDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetTeamDataSucceeded]) {
        self.teams = [notification.userInfo objectForKey:kGetTeamDataSucceeded];
        [self.tableTableView reloadData];
    }
}

-(void)getTeamDataFailed:(NSNotification*)notification {
}

#pragma mark - TableData notification
-(void)getTableDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetTableDataSucceeded]) {
        NSArray* teams = [notification.userInfo objectForKey:kGetTableDataSucceeded];
        [self.groups removeAllObjects];
        for (FITableTeamData* team in teams) {
            [self addTeam:team];
        }
        
        NSArray* tmp = [self.groups sortedArrayUsingSelector:@selector(compareName:)];
        self.groups = [[NSMutableArray alloc] initWithArray:tmp];
        
        for (FITableGroupData* group in self.groups) {
            [group sortTeamsByPointAndGoal];
        }
        
        [self.tableTableView reloadData];
    }
}

-(void)getTableDataFailed:(NSNotification*)notification {
}

///Add a team data to group data. Create group of that team if it is not existed
-(void)addTeam:(FITableTeamData*)team {
    NSString* groupName = team.groupName;
    bool teamAdded = NO;
    for (int i = 0; i < [self.groups count]; i++) {
        FITableGroupData* group = [self.groups objectAtIndex:i];
        if ([groupName isEqualToString:group.groupName]) {
            [group.teams addObject:team];
            teamAdded = YES;
            break;
        }
    }
    
    if (!teamAdded) {
        FITableGroupData* group = [[FITableGroupData alloc] init];
        group.groupName = groupName;
        [group.teams addObject:team];
        
        [self.groups addObject:group];
    }
}

-(FITeamData*)getTeamForId:(NSInteger)teamId {
    FITeamData* team = nil;
    for (int i = 0; i < [self.teams count]; i++) {
        FITeamData* aTeam = [self.teams objectAtIndex:i];
        if (aTeam.teamid == teamId) {
            team = aTeam;
            break;
        }
    }
    
    return team;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    FITeamInfoViewController* teamInfoViewController = [segue destinationViewController];
    teamInfoViewController.teamID = self.selectedTeamId;
}

@end
