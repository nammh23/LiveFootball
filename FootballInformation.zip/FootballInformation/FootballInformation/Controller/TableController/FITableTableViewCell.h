//
//  FITableTableViewCell.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FITableTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *rankLabel;
@property (weak, nonatomic) IBOutlet UILabel *teamNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchWinLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchDrawLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchLoseLabel;
@property (weak, nonatomic) IBOutlet UILabel *pointLabel;

@end
