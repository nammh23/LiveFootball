//
//  FILeagueListTableViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/19/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FILeagueListTableViewController.h"
#import "FILeagueInformation.h"
#import "FIListLeagueTableViewCell.h"
#import "FIUtil.h"
#import "FIConfig.h"
#import "FITableViewController.h"

@interface FILeagueListTableViewController ()
@property (nonatomic) NSInteger selectedLeagueId;
@property (readwrite) NSMutableArray* listLeague;
@end

@implementation FILeagueListTableViewController
//-(void) setListLeague:(NSMutableArray *)listLeague{
//    _listLeague = listLeague;
//}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedLeagueId = 0;
    self.listLeague = [[NSMutableArray alloc] init];
    FILeagueInformation* EPL = [[FILeagueInformation alloc] init];
    EPL.leagueID = 1204;
    EPL.leagueName = @"English Premier League";
    EPL.region = @"England";
    EPL.avatarURL = @"http://bongdaso.com/img/Country/eng.gif";
    [[self listLeague] addObject:EPL];
    NSLog(@"Leagueeeeeeee%@",self.listLeague);
    FILeagueInformation* Bundesliga = [[FILeagueInformation alloc] init];
    Bundesliga.leagueID = 1229;
    Bundesliga.leagueName = @"Bundesliga - Germany";
    Bundesliga.region = @"Germany";
    Bundesliga.avatarURL = @"http://bongdaso.com/img/Country/ger.gif";
    [[self listLeague] addObject:Bundesliga];
    
    FILeagueInformation* Laliga = [[FILeagueInformation alloc] init];
    Laliga.leagueID = 1399;
    Laliga.leagueName = @"La Liga - Spain";
    Laliga.region = @"Spain";
    Laliga.avatarURL = @"http://bongdaso.com/img/Country/esp.gif";
    [[self listLeague] addObject:Laliga];
    
    FILeagueInformation* Thaileague = [[FILeagueInformation alloc] init];
    Thaileague.leagueID = 1415;
    Thaileague.leagueName = @"Thai Premeir League";
    Thaileague.region = @"Thailand";
    Thaileague.avatarURL = @"http://bongdaso.com/img/Country/tha.gif";
    [self.listLeague addObject:Thaileague];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:BACKGROUND_IMAGE_NAVIGATION_BAR] forBarMetrics:UIBarMetricsDefault];
    
    NSDictionary *attributes = @{UITextAttributeTextColor: [UIColor whiteColor],
                                 UITextAttributeFont: [UIFont fontWithName:NAVIGATION_BAR_FONT_NAME size:NAVIGATION_BAR_FONT_SIZE]};
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[self listLeague] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FIListLeagueTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"listLeagueTable" forIndexPath:indexPath];
    if(cell == nil){
        cell = [[FIListLeagueTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"listLeagueTable"];
    }
    NSInteger index = [indexPath row];
    if(index >=0 && index < [self.listLeague count] ){
        FILeagueInformation *league = [[self listLeague] objectAtIndex:index];
        cell.leagueNameLabel.text = league.leagueName;
        __weak FIListLeagueTableViewCell* weakCell = cell;
        NSString* avatarPath = [[FIUtil getTeamAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png",league.leagueID]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
            NSURL *avatarURL = [NSURL URLWithString:league.avatarURL];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    // Update the UI
                    UIImage *image = [UIImage imageWithData:imageData];
                    weakCell.logoImageView.image = image;
                    
                    //save
                    [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                });
            });
        } else {
            cell.logoImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
        }

    }
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    FITableViewController* table = [segue destinationViewController];
    NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
    table.leagueID = [[self.listLeague objectAtIndex:indexPath.row] leagueID];

}


@end
