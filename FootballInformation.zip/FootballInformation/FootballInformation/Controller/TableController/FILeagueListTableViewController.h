//
//  FILeagueListTableViewController.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/19/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FILeagueListTableViewController : UITableViewController
//@property(nonatomic, strong) NSMutableArray *listLeague; //List of league that api support
@end
