//
//  FITableGroupData.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FITableGroupData : NSObject
@property (strong, nonatomic) NSString* groupName;
@property (strong, nonatomic) NSMutableArray* teams;

-(void)sortTeamsByRank;
-(void)sortTeamsByPointAndGoal;

-(NSComparisonResult)compareName:(FITableGroupData*)rhs;


@end
