//
//  FITableHeaderViewCell.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FITableHeaderViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *groupNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchWinLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchDrawLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchLoseLabel;
@property (weak, nonatomic) IBOutlet UILabel *pointLabel;


@end
