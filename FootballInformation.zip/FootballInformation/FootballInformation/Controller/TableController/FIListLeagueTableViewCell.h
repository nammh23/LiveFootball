//
//  FIListLeagueTableViewCell.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/19/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FIListLeagueTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *leagueNameLabel;

@end
