//
//  FITableGroupData.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FITableGroupData.h"

@implementation FITableGroupData
-(instancetype)init {
    self = [super init];
    if (self) {
        _teams = [[NSMutableArray alloc] init];
    }
    
    return self;
}

-(void)sortTeamsByRank {
    NSArray* tmp = [self.teams sortedArrayUsingSelector:@selector(compareRank:)];
    
    self.teams = [[NSMutableArray alloc] initWithArray:tmp];
}

-(void)sortTeamsByPointAndGoal {
    NSArray* tmp = [self.teams sortedArrayUsingSelector:@selector(comparePointAndGoal:)];
    
    //reverse
    NSMutableArray* tmp2 = [[NSMutableArray alloc] init];
    for (int i = [tmp count] - 1; 0 <= i; i--) {
        [tmp2 addObject:[tmp objectAtIndex:i]];
    }
    
    self.teams = [[NSMutableArray alloc] initWithArray:tmp2];
}

-(NSComparisonResult)compareName:(FITableGroupData *)rhs {
    return [self.groupName caseInsensitiveCompare:rhs.groupName];
}
@end
