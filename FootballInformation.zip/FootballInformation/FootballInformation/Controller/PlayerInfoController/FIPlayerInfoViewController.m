//
//  FIPlayerInfoViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FIPlayerInfoViewController.h"
#import "FIPlayerData.h"
#import "FIDataGetter.h"
#import "FIPlayerTableViewCell.h"
#import "FIUtil.h"
#import "FIConfig.h"

@interface FIPlayerInfoViewController ()
@property (strong, nonatomic) FIPlayerData* player;

@end

@implementation FIPlayerInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (IS_IPHONE) {
        self.titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_PLAYER_INFO_IPHONE]];
    } else {
        self.titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_PLAYER_INFO_IPAD]];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPlayerDataFULLSucceeded:) name:kGetPlayerDataFULLSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPlayerDataFULLFailed:) name:kGetPlayerDataFULLFailed object:nil];
    
    self.infoTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]];
    
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setPlayerId:(NSInteger)playerId {
    _playerId = playerId;
    [FIDataGetter getPlayerDataFull:playerId];
}

-(void)setPlayer:(FIPlayerData *)player {
    _player = player;
    [self updateUI];
}

-(void)getPlayerDataFULLSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetPlayerDataFULLSucceeded]) {
        FIPlayerData* player = [notification.userInfo objectForKey:kGetPlayerDataFULLSucceeded];
        if (player.playerId == self.playerId) {
            self.player = player;
        }
    }
}

-(void)getPlayerDataFULLFailed:(NSNotification*)notification {
}

-(void)updateUI {
    NSString* avatarPath = [[FIUtil getPlayerAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%d.png", self.player.playerId]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
        NSURL *avatarURL = [NSURL URLWithString:self.player.avatarURL];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                // Update the UI
                UIImage *image = [UIImage imageWithData:imageData];
                self.avatarImageView.image = image;
                
                //save
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            });
        });
    } else {
        self.avatarImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
    }
    self.nameLabel.text = self.player.name;
    
    [self.infoTableView reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 8;
}

NSString* DOB_TITLE = @"Date of birth:";
NSString* POB_TITLE = @"Place of birth:";
NSString* NATIONALITY_TITLE = @"Nationality:";
NSString* POSITION_TITLE = @"Position:";
NSString* CLUB_TITLE = @"Club:";
NSString* HEIGHT_TITLE = @"Height:";
NSString* WEIGHT_TITLE = @"Weight:";
NSString* NUMBER_TITLE = @"Number:";

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString* cellIdentifier = @"playerInfoTableCell";
    FIPlayerTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[FIPlayerTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    //selected background
    UIView *bgSelectedColorView = [[UIView alloc] init];
    bgSelectedColorView.backgroundColor = [UIColor colorWithRed:TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED green:TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN blue:TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE alpha:TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA];
    bgSelectedColorView.layer.masksToBounds = YES;
    [cell setSelectedBackgroundView:bgSelectedColorView];
    
    [cell.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    
    switch (indexPath.row) {
        case 0: //dob
        {
            cell.titleLabel.text = DOB_TITLE;
            cell.valueLabel.text = self.player.dateOfBirth;
        }
            break;
            
        case 1: //POB
        {
            cell.titleLabel.text = POB_TITLE;
            cell.valueLabel.text = self.player.placeOfBirth;
        }
            break;
            
        case 2: //nationality
        {
            cell.titleLabel.text = NATIONALITY_TITLE;
            cell.valueLabel.text = self.player.nationality;
        }
            break;
            
        case 3: //position
        {
            cell.titleLabel.text = POSITION_TITLE;
            cell.valueLabel.text = self.player.position;
        }
            break;
            
        case 4: //club
        {
            cell.titleLabel.text = CLUB_TITLE;
            cell.valueLabel.text = self.player.club;
        }
            break;
            
        case 5: //height
        {
            cell.titleLabel.text = HEIGHT_TITLE;
            cell.valueLabel.text = self.player.height;
        }
            break;
            
        case 6: //weight
        {
            cell.titleLabel.text = WEIGHT_TITLE;
            cell.valueLabel.text = self.player.weight;
        }
            break;
            
        case 7: //number
        {
            cell.titleLabel.text = NUMBER_TITLE;
            cell.valueLabel.text = self.player.number;
        }
            break;
            
        default: {
            cell.titleLabel.text = EMPTY_STRING;
            cell.valueLabel.text = EMPTY_STRING;
        }
            break;
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

@end
