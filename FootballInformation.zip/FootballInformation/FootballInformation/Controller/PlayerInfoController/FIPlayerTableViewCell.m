//
//  FIPlayerTableViewCell.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FIPlayerTableViewCell.h"

@implementation FIPlayerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
