//
//  FILiveScoreViewController.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface FILiveScoreViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIView *dateViewContainer;
@property (weak, nonatomic) IBOutlet UITableView *scoreTableView;

@end

