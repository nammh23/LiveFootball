//
//  FIStatisticsViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//


#import "FIStatisticsViewController.h"
#import "FIStatisticsHeaderTableViewCell.h"
#import "FIStatisticsTableViewCell.h"
#import "FIStatMatchItemData.h"
#import "FIDataGetter.h"
#import "FITeamData.h"
#import "FITeamInfoViewController.h"
#import "FIUtil.h"
#import "FIConfig.h"

@interface FIStatisticsViewController ()
@property (strong, nonatomic) NSArray* teams; //of FITeamData
@property (nonatomic) NSInteger selectedTeamId;

@property (strong, nonatomic) UIRefreshControl *refreshControl;

@end

@implementation FIStatisticsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.statInfos = [[NSArray alloc] init];
    self.teams = [[NSArray alloc] init];
    
    self.dataTableView.backgroundView = nil;
    self.dataTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]];
    if ([self.dataTableView respondsToSelector:@selector(separatorInset)]) {
        [self.dataTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"6.0")) {
        self.refreshControl = [[UIRefreshControl alloc] init];
        [self.dataTableView addSubview:self.refreshControl];
        [self.refreshControl addTarget:self action:@selector(refreshTable) forControlEvents:UIControlEventValueChanged];
    }
    
    //fix separator issues
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.dataTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        self.dataTableView.separatorColor = [UIColor darkGrayColor];
    } else {
        self.dataTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.dataTableView.separatorColor = [UIColor blackColor];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataSucceeded:) name:kGetTeamDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataFailed:) name:kGetTeamDataFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getStatMatchDataSucceeded:) name:kGetStatMatchDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getStatMatchDataFailed:) name:kGetStatMatchDataFailed object:nil];
    
    [FIDataGetter getTeamData];
    [self loadData];
}

-(void)loadData {
    [FIDataGetter getStatMatchData:self.match.matchID];
}

- (void)refreshTable {
    [self.refreshControl endRefreshing];
    [self loadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setStatInfos:(NSArray *)statInfos {
    _statInfos = statInfos;
    [self updateUI];
}

-(void)setMatch:(FIScheduleMatchData *)match {
    _match = match;
    [self loadData];
}

-(void)setTeams:(NSArray *)teams {
    _teams = teams;
    [self updateUI];
}

-(void)updateUI {
    FITeamData* team = [self getTeamForId:self.match.homeId];
    UIColor* highlightedColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_HIGHLIGHTED]];
    
    [self.homeNameButton setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    [self.awayNameButton setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    
    [self.homeNameButton setTitle:team.name forState:UIControlStateNormal];
    [self.homeNameButton setTitle:team.name forState:UIControlStateHighlighted];
    
    __weak FIStatisticsViewController* weakSelf = self;
    NSString* avatarPath = [[FIUtil getTeamAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png", (long)team.teamid]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
        NSURL *avatarURL = [NSURL URLWithString:team.avatarURL];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                // Update the UI
                UIImage *image = [UIImage imageWithData:imageData];
                weakSelf.homeLogoImageView.image = image;
                
                //save
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            });
        });
    } else {
        self.homeLogoImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
    }
    
    team = [self getTeamForId:self.match.awayId];
    [self.awayNameButton setTitle:team.name forState:UIControlStateNormal];
    [self.awayNameButton setTitle:team.name forState:UIControlStateHighlighted];
    
    avatarPath = [[FIUtil getTeamAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png", (long)team.teamid]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
        NSURL *avatarURL = [NSURL URLWithString:team.avatarURL];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                // Update the UI
                UIImage *image = [UIImage imageWithData:imageData];
                weakSelf.awayLogoImageView.image = image;
                
                //save
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            });
        });
    } else {
        self.awayLogoImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
    }
    
    [self.homeNameButton addTarget:self action:@selector(didTapHomeTeam:) forControlEvents:UIControlEventTouchUpInside];
    UITapGestureRecognizer *tapGestureHome = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapHomeTeam:)];
    [self.homeLogoImageView addGestureRecognizer:tapGestureHome];
    
    [self.awayNameButton addTarget:self action:@selector(didTapAwayTeam:) forControlEvents:UIControlEventTouchUpInside];
    UITapGestureRecognizer *tapGestureAway = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAwayTeam:)];
    [self.awayLogoImageView addGestureRecognizer:tapGestureAway];
    
    [self.dataTableView reloadData];
}

#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.statInfos count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString* cellIdentifier = @"statisticsCellIdentifier";
    FIStatisticsTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[FIStatisticsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    [cell.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    FIStatMatchItemData* data = [self.statInfos objectAtIndex:indexPath.row];
    cell.nameLabel.text = data.name;
    cell.homeValueLabel.text = data.homeValue;
    cell.awayValueLabel.text = data.awayValue;
    
    return cell;
}

#pragma mark -  data getter
-(void)getTeamDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetTeamDataSucceeded]) {
        self.teams = [notification.userInfo objectForKey:kGetTeamDataSucceeded];
    }
}

-(void)getTeamDataFailed:(NSNotification*)notification {
}

-(void)getStatMatchDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetStatMatchDataSucceeded]) {
        NSInteger matchID = [[notification.userInfo objectForKey:kGetStatMatchDataSucceededMatchId] integerValue];
        if (matchID == self.match.matchID || matchID == TEST_MATCH_ID) {
            self.statInfos = [notification.userInfo objectForKey:kGetStatMatchDataSucceeded];
        }
    }
}

-(void)getStatMatchDataFailed:(NSNotification*)notification {
}

-(FITeamData*)getTeamForId:(NSInteger)teamId {
    //    static NSInteger testId = 1;
    //    testId ++;
    //    if (testId % 2 == 0) {
    //        teamId = 164;
    //    } else {
    //        teamId = 182;
    //    }
    FITeamData* team = nil;
    for (int i = 0; i < [self.teams count]; i++) {
        FITeamData* aTeam = [self.teams objectAtIndex:i];
        if (aTeam.teamid == teamId) {
            team = aTeam;
            break;
        }
    }
    
    return team;
}

NSString* const kStatToTeamInfoSegueIdentifier = @"statToTeamInfoSegue";

-(void)didTapHomeTeam:(UITapGestureRecognizer *)tapGesture {
    self.selectedTeamId = self.match.homeId;
    //    self.selectedTeamId = 164;
    [self performSegueWithIdentifier:kStatToTeamInfoSegueIdentifier sender:nil];
}

-(void)didTapAwayTeam:(UITapGestureRecognizer *)tapGesture {
    self.selectedTeamId = self.match.awayId;
    //    self.selectedTeamId = 182;
    [self performSegueWithIdentifier:kStatToTeamInfoSegueIdentifier sender:nil];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    FITeamInfoViewController* teamInfoViewController = [segue destinationViewController];
    teamInfoViewController.teamID = self.selectedTeamId;
}


@end
