//
//  FIStatisticsViewController.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FIScheduleMatchData.h"

@interface FIStatisticsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIView *titleView;
@property (weak, nonatomic) IBOutlet UITableView *dataTableView;

@property (strong, nonatomic) NSArray* statInfos; //of FIStatMatchItemData
@property (strong, nonatomic) FIScheduleMatchData* match;

@property (weak, nonatomic) IBOutlet UIButton *homeNameButton;
@property (weak, nonatomic) IBOutlet UIImageView *homeLogoImageView;
@property (weak, nonatomic) IBOutlet UIButton *awayNameButton;
@property (weak, nonatomic) IBOutlet UIImageView *awayLogoImageView;
@end
