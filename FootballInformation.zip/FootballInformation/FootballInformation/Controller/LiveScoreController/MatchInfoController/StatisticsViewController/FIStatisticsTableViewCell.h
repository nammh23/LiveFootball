//
//  FIStatisticsTableViewCell.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FIStatisticsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *homeValueLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *awayValueLabel;

@end
