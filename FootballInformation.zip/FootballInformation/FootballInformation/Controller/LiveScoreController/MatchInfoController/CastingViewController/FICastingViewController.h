//
//  FICastingViewController.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FICastingViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) NSArray* castingInfos; //of FICastingData
@property (nonatomic) NSInteger matchId;

@property (weak, nonatomic) IBOutlet UITableView *dataTableView;

@end
