//
//  FICastingViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FICastingViewController.h"
#import "FIDataGetter.h"
#import "FICastingTableViewCell.h"
#import "FICastingData.h"
#import "FIConfig.h"
#import "FIUtil.h"

@interface FICastingViewController ()
@property (strong, nonatomic) UIRefreshControl *refreshControl;
@end

@implementation FICastingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.castingInfos = [[NSArray alloc] init];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCastingDataSucceeded:) name:kGetCastingDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCastingDataFailed:) name:kGetCastingDataFailed object:nil];
    
    //data table
    self.dataTableView.backgroundView = nil;
    self.dataTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]];
    
    if ([self.dataTableView respondsToSelector:@selector(separatorInset)]) {
        [self.dataTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"6.0")) {
        self.refreshControl = [[UIRefreshControl alloc] init];
        [self.dataTableView addSubview:self.refreshControl];
        [self.refreshControl addTarget:self action:@selector(refreshTable) forControlEvents:UIControlEventValueChanged];
    }
    
    [self loadData];
}

- (void)refreshTable {
    [self.refreshControl endRefreshing];
    [self loadData];
}

-(void)loadData {
    [FIDataGetter getCastingData:self.matchId];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setCastingInfos:(NSArray *)castingInfos {
    //reverse
    NSMutableArray* tmp = [[NSMutableArray alloc] init];
    for (int i = [castingInfos count] - 1; 0 <= i; i--) {
        [tmp addObject:[castingInfos objectAtIndex:i]];
    }
    _castingInfos = [NSArray arrayWithArray:tmp];
    [self.dataTableView reloadData];
}

-(void)setMatchId:(NSInteger)matchId {
    _matchId = matchId;
    [self loadData];
}

-(void)getCastingDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetCastingDataSucceeded]) {
        NSInteger matchID = [[notification.userInfo objectForKey:kGetCastingDataSucceededMatchId] integerValue];
        if (matchID == self.matchId || matchID == TEST_MATCH_ID) {
            self.castingInfos = [notification.userInfo objectForKey:kGetCastingDataSucceeded];
        }
    }
}

-(void)getCastingDataFailed:(NSNotification*)notification {
}

#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.castingInfos count];
}

const float kCellMargin = 11.0f;
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString* cellIdentifier = @"castingCellIdentifier";
    FICastingTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[FICastingTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    [cell.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    
    FICastingData* data = [self.castingInfos objectAtIndex:indexPath.row];
    cell.timeLabel.text = data.time;
    cell.scoreLabel.text = data.score;
    cell.infoLabel.text = data.info;
    cell.infoLabel.frame = CGRectMake(cell.infoLabel.frame.origin.x, cell.infoLabel.frame.origin.y, cell.infoLabel.frame.size.width, cell.frame.size.height - kCellMargin);
    
    return cell;
}

const float kMaxCellHeight = 1000000.0f;
const float kCellWidth = 200.0f;
const float kDefaultFontSize = 12.0f;
const float kDefaultCellHeight = 44.0f;

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat cellHeight = kDefaultCellHeight;
    FICastingData* data = [self.castingInfos objectAtIndex:indexPath.row];
    NSString *text = data.info;
    CGSize constraint = CGSizeMake(kCellWidth, kMaxCellHeight);
    CGSize size = [text sizeWithFont:[UIFont fontWithName:@"Helvetica" size:kDefaultFontSize] constrainedToSize:constraint lineBreakMode:NSLineBreakByTruncatingTail];
    return cellHeight + size.height;
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
