//
//  FIMatchInfoViewController.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FIScheduleMatchData.h"

@interface FIMatchInfoViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *dataView;
@property (weak, nonatomic) IBOutlet UIView *pageButtonContainerView;
@property (weak, nonatomic) IBOutlet UIButton *castingButton;
@property (weak, nonatomic) IBOutlet UIButton *statButton;
@property (weak, nonatomic) IBOutlet UIButton *lineupButton;

@property (strong, nonatomic) FIScheduleMatchData* match;
@end
