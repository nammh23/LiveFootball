//
//  FIMatchInfoViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//
#import "FIMatchInfoViewController.h"
#import "FICastingViewController.h"
#import "FIStatisticsViewController.h"
#import "FILineupViewController.h"
#import "FIDataGetter.h"
#import "FIConfig.h"
#import "FIUtil.h"


@interface FIMatchInfoViewController ()

@property (strong, nonatomic) FICastingViewController* castingViewController;
@property (strong, nonatomic) FIStatisticsViewController *statisticsViewController;
@property (strong, nonatomic) FILineupViewController* lineupViewController;

@property (strong, nonatomic) NSArray* castingInfos; //of FICastingData
@property (strong, nonatomic) NSArray* statInfos; //of FIStatMatchItemData

@end

@implementation FIMatchInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.pageButtonContainerView.layer.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_DATE_VIEW]].CGColor;
    self.pageButtonContainerView.layer.borderColor = [UIColor darkGrayColor].CGColor;
    self.pageButtonContainerView.layer.borderWidth = 0.5f;
    
    UIColor* highlightedColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_HIGHLIGHTED]];
    [self.castingButton setBackgroundImage:[UIImage imageNamed:BACKGROUND_IMAGE_DATE_VIEW] forState:UIControlStateNormal];
    [self.castingButton setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    
    [self.statButton setBackgroundImage:[UIImage imageNamed:BACKGROUND_IMAGE_DATE_VIEW] forState:UIControlStateNormal];
    [self.statButton setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    
    [self.lineupButton setBackgroundImage:[UIImage imageNamed:BACKGROUND_IMAGE_DATE_VIEW] forState:UIControlStateNormal];
    [self.lineupButton setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    
    [self loadChildrenViewControllers];
    
    if (self.castingInfos == nil) {
        self.castingInfos = [[NSArray alloc] init];
    }
    
    if (self.statInfos) {
        self.statInfos = [[NSArray alloc] init];
    }
    
    if (self.match == nil) {
        self.match = [[FIScheduleMatchData alloc] init];
    }
    [self pageButtonClicked:self.castingButton];
}

-(void)loadChildrenViewControllers {
    if (self.castingViewController == nil) {
        self.castingViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"castingViewController"];
    }
    if (self.statisticsViewController == nil) {
        self.statisticsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"statisticsViewController"];
    }
    
    if (self.lineupViewController == nil) {
        self.lineupViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"lineupViewController"];
    }
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setMatch:(FIScheduleMatchData *)match {
    _match = match;
    [self loadChildrenViewControllers];
    self.statisticsViewController.match = match;
    self.castingViewController.matchId = match.matchID;
    self.lineupViewController.match = match;
}

- (void)displayContentController: (UIViewController*) content;
{
    [self addChildViewController:content];
    content.view.frame = CGRectMake(0, 0, self.dataView.frame.size.width, self.dataView.frame.size.height);
    [self.dataView addSubview:content.view];
    [content didMoveToParentViewController:self];
}

- (void)hideContentController: (UIViewController*) content
{
    [content willMoveToParentViewController:nil];
    [content.view removeFromSuperview];
    [content removeFromParentViewController];
}

- (IBAction)pageButtonClicked:(UIButton *)sender {
    __weak UIButton* highlightedButton;
    __weak UIButton* unhighlightedButton1;
    __weak UIButton* unhighlightedButton2;
    
    if (sender == self.castingButton) {
        [self hideContentController:self.statisticsViewController];
        [self hideContentController:self.lineupViewController];
        [self displayContentController:self.castingViewController];
        
        highlightedButton = self.castingButton;
        unhighlightedButton1 = self.statButton;
        unhighlightedButton2 = self.lineupButton;
    } else if (sender == self.statButton) {
        [self hideContentController:self.castingViewController];
        [self hideContentController:self.lineupViewController];
        [self displayContentController:self.statisticsViewController];
        
        highlightedButton = self.statButton;
        unhighlightedButton1 = self.castingButton;
        unhighlightedButton2 = self.lineupButton;
    } else if (sender == self.lineupButton) {
        [self hideContentController:self.castingViewController];
        [self hideContentController:self.statisticsViewController];
        [self displayContentController:self.lineupViewController];
        
        highlightedButton = self.lineupButton;
        unhighlightedButton1 = self.castingButton;
        unhighlightedButton2 = self.statButton;
    }
    
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        highlightedButton.highlighted = YES;
        unhighlightedButton1.highlighted = NO;
        unhighlightedButton2.highlighted = NO;
    }];
}

@end
