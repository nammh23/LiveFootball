//
//  FILineupViewController.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FIScheduleMatchData.h"

@interface FILineupViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) FIScheduleMatchData* match;

@property (weak, nonatomic) IBOutlet UIButton *homeNameButton;
@property (weak, nonatomic) IBOutlet UIButton *awayNameButton;
@property (weak, nonatomic) IBOutlet UITableView *dataTableView;

@end
