//
//  FILineupViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FILineupViewController.h"
#import "FIDataGetter.h"
#import "FITeamData.h"
#import "FIUtil.h"
#import "FIConfig.h"
#import "FILineupData.h"
#import "FIPlayerNameTableViewCell.h"
#import "FIPlayerInfoViewController.h"

@interface FILineupViewController ()

@property (strong, nonatomic) NSArray* teams; //of FITeamData
@property (nonatomic) bool homeTeamSelected;
@property (nonatomic) NSInteger selectedPlayerId;

@property (strong, nonatomic) FILineupData* lineupData;

@end

@implementation FILineupViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.homeTeamSelected = YES;
    self.homeNameButton.highlighted = YES;
    self.teams = [[NSArray alloc] init];
    self.lineupData = [[FILineupData alloc] init];
    
    self.dataTableView.backgroundView = nil;
    self.dataTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]];
    if ([self.dataTableView respondsToSelector:@selector(separatorInset)]) {
        [self.dataTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    //fix separator issues
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.dataTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        self.dataTableView.separatorColor = [UIColor darkGrayColor];
    } else {
        self.dataTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.dataTableView.separatorColor = [UIColor blackColor];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataSucceeded:) name:kGetTeamDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataFailed:) name:kGetTeamDataFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getLineUpMatchDataSucceeded:) name:kGetLineUpMatchDataSucceeded object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getLineUpMatchDataFailed:) name:kGetLineUpMatchDataFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPlayerDataFULLSucceeded:) name:kGetPlayerDataFULLSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPlayerDataFULLFailed:) name:kGetPlayerDataFULLFailed object:nil];
    
    [FIDataGetter getTeamData];
    [self loadData];
    
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

-(void)setMatch:(FIScheduleMatchData *)match {
    _match = match;
    [self loadData];
}

-(void)setLineupData:(FILineupData *)lineupData {
    _lineupData = lineupData;
    [self updateUI];
}

-(void)setTeams:(NSArray *)teams {
    _teams = teams;
    [self updateUI];
}

-(void)loadData {
    [FIDataGetter getLineUpMatchData:self.match.matchID];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)updateUI {
    FITeamData* team = [self getTeamForId:self.match.homeId];
    UIColor* highlightedColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_HIGHLIGHTED]];
    
    [self.homeNameButton setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    [self.awayNameButton setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    
    [self.homeNameButton setTitle:team.name forState:UIControlStateNormal];
    [self.homeNameButton setTitle:team.name forState:UIControlStateHighlighted];
    
    team = [self getTeamForId:self.match.awayId];
    [self.awayNameButton setTitle:team.name forState:UIControlStateNormal];
    [self.awayNameButton setTitle:team.name forState:UIControlStateHighlighted];
    
    [self.dataTableView reloadData];
}

-(void)setPlayerData:(FIPlayerData*)player {
    NSInteger pos = [self findPlayerData:player forPlayerInList:self.lineupData.homeLineUp];
    if (pos != -1) {
        [self.lineupData.homeLineUp replaceObjectAtIndex:pos withObject:player];
    } else {
        pos = [self findPlayerData:player forPlayerInList:self.lineupData.homeSubs];
        if (pos != -1) {
            [self.lineupData.homeSubs replaceObjectAtIndex:pos withObject:player];
        } else {
            pos = [self findPlayerData:player forPlayerInList:self.lineupData.awayLineUp];
            if (pos != -1) {
                [self.lineupData.awayLineUp replaceObjectAtIndex:pos withObject:player];
            } else {
                pos = [self findPlayerData:player forPlayerInList:self.lineupData.awaySubs];
                if (pos != -1) {
                    [self.lineupData.awaySubs replaceObjectAtIndex:pos withObject:player];
                }
            }
        }
    }
    
    [self.dataTableView reloadData];
}

-(NSInteger)findPlayerData:(FIPlayerData*)player forPlayerInList:(NSMutableArray*)list {
    for (int i = 0; i < [list count]; i++) {
        FIPlayerData* tmp = [list objectAtIndex:i];
        if (tmp.playerId == player.playerId && tmp.avatarURL == nil) {
            return i;
        }
    }
    return -1;
}
- (IBAction)didTeamButtonClicked:(UIButton *)sender {
    __weak UIButton* highlightedButton;
    __weak UIButton* unhighlightedButton;
    
    if (sender == self.homeNameButton) {
        highlightedButton = self.homeNameButton;
        unhighlightedButton = self.awayNameButton;
        
        self.homeTeamSelected = YES;
    } else {
        highlightedButton = self.awayNameButton;
        unhighlightedButton = self.homeNameButton;
        
        self.homeTeamSelected = NO;
    }
    
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        highlightedButton.highlighted = YES;
        unhighlightedButton.highlighted = NO;
    }];
    
    [self.dataTableView reloadData];
}


#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

#define LINEUP_INFO_LINEUP_SECTION 0
#define LINEUP_INFO_SUBS_SECTION 1

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case LINEUP_INFO_LINEUP_SECTION:
        {
            //lineup
            return self.homeTeamSelected ? [self.lineupData.homeLineUp count] : [self.lineupData.awayLineUp count];
        }
            break;
            
        case LINEUP_INFO_SUBS_SECTION:
        {
            //sub
            return self.homeTeamSelected ? [self.lineupData.homeSubs count] : [self.lineupData.awaySubs count];
        }
            
        default:
            return 0;
            break;
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellIdentifier = @"teamInfoTableCell";
    FIPlayerNameTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[FIPlayerNameTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    //selected background
    UIView *bgSelectedColorView = [[UIView alloc] init];
    bgSelectedColorView.backgroundColor = [UIColor colorWithRed:TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED green:TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN blue:TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE alpha:TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA];
    bgSelectedColorView.layer.masksToBounds = YES;
    [cell setSelectedBackgroundView:bgSelectedColorView];
    
    [cell.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    
    FIPlayerData* player = [self getPlayerAtIndexPath:indexPath];
    if (player) {
        if (player.avatarURL == nil) {
            [FIDataGetter getPlayerDataFull:player.playerId];
        }
        cell.numberLabel.text = player.number;
        cell.nameLabel.text = player.name;
        
        __weak FIPlayerNameTableViewCell* weakCell = cell;
        NSString* avatarPath = [[FIUtil getPlayerAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%d.png", player.playerId]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
            if (player.avatarURL) {
                NSURL *avatarURL = [NSURL URLWithString:player.avatarURL];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                    NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        // Update the UI
                        UIImage *image = [UIImage imageWithData:imageData];
                        weakCell.avatarImageView.image = image;
                        
                        //save
                        [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                    });
                });
            }
        } else {
            cell.avatarImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
        }
    }
    
    return cell;
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString * language = [[NSLocale preferredLanguages] objectAtIndex:0];
    
    if (section == LINEUP_INFO_LINEUP_SECTION) {
        if ([language isEqualToString:LANGUAGE_VIETNAMESE_STRING]) {
            return @"Đội hình chính";
        } else {
            return @"Lineup";
        }
    } else {
        if ([language isEqualToString:LANGUAGE_VIETNAMESE_STRING]) {
            return @"Dự bị";
        } else {
            return @"Substitute";
        }
    }
}

NSString* const kLineupToPlayerInfoSegueIdentifier = @"lineupToPlayerInfoSegue";
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FIPlayerData* player = [self getPlayerAtIndexPath:indexPath];
    if (player) {
        self.selectedPlayerId = player.playerId;
        [self performSegueWithIdentifier:kLineupToPlayerInfoSegueIdentifier sender:nil];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark -  data getter
-(void)getTeamDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetTeamDataSucceeded]) {
        self.teams = [notification.userInfo objectForKey:kGetTeamDataSucceeded];
    }
}

-(void)getTeamDataFailed:(NSNotification*)notification {
}

-(void)getLineUpMatchDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetLineUpMatchDataSucceeded]) {
        FILineupData* data = [notification.userInfo objectForKey:kGetLineUpMatchDataSucceeded];
        if (data.matchId == self.match.matchID || data.matchId == TEST_MATCH_ID) {
            self.lineupData = data;
        }
    }
}

-(void)getLineUpMatchDataFailed:(NSNotification*)notification {
}

-(void)getPlayerDataFULLSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetPlayerDataFULLSucceeded]) {
        FIPlayerData* player = [notification.userInfo objectForKey:kGetPlayerDataFULLSucceeded];
        [self setPlayerData:player];
    }
}

-(void)getPlayerDataFULLFailed:(NSNotification*)notification {
}

-(FIPlayerData*)getPlayerAtIndexPath:(NSIndexPath*)indexPath {
    NSMutableArray* list;
    if (indexPath.section == LINEUP_INFO_SUBS_SECTION) {
        //sub
        list = self.homeTeamSelected ? self.lineupData.homeSubs : self.lineupData.awaySubs;
    } else {
        //lineup
        list = self.homeTeamSelected ? self.lineupData.homeLineUp : self.lineupData.awayLineUp;
    }
    
    FIPlayerData* player;
    if (indexPath.row < [list count]) {
        player = [list objectAtIndex:indexPath.row];
    }
    return player;
}

-(FITeamData*)getTeamForId:(NSInteger)teamId {
    FITeamData* team = nil;
    for (int i = 0; i < [self.teams count]; i++) {
        FITeamData* aTeam = [self.teams objectAtIndex:i];
        if (aTeam.teamid == teamId) {
            team = aTeam;
            break;
        }
    }
    
    return team;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    FIPlayerInfoViewController* destController = [segue destinationViewController];
    destController.playerId = self.selectedPlayerId;
}
@end

