//
//  FILiveScoreViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//
#import "FILiveScoreViewController.h"
#import "SWRevealViewController.h"
#import "FIUtil.h"
#import "FIConfig.h"
#import "FIScoreTableViewCell.h"
#import "FIDateView.h"
#import "FIDataGetter.h"
#import "FITeamData.h"
#import "FIScheduleMatchData.h"
#import "FIMatchInfoViewController.h"

@interface FILiveScoreViewController ()

@property (strong, nonatomic) FIDateView *dateView;
@property (strong, nonatomic) NSDate* selectedDate;
@property (strong, nonatomic) NSArray* matches; //of FIScheduleMatchData
@property (strong, nonatomic) NSMutableArray* selectedMatches; //of FIScheduleMatchData
@property (strong, nonatomic) NSArray* teams; //of FITeamData
@property (nonatomic) bool matchesNewUpdate; //use to fix error when livescore not show and we have to re-select date
@property (nonatomic) bool dateViewSet; //whether dates in dateView were set

@property (nonatomic) NSInteger selectedRow; //row of match which is selected to view data

//@property (nonatomic, strong) FIPictureViewController* pictureViewController;

@property (strong, nonatomic) UIRefreshControl *refreshControl;

@end

@implementation FILiveScoreViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //remove caches
    
    self.matches = [[NSArray alloc] init];
    self.selectedMatches = [[NSMutableArray alloc] init];
    self.selectedDate = [NSDate date];
    self.teams = [[NSArray alloc] init];
    self.matchesNewUpdate = YES;
    self.dateViewSet = NO;
    self.selectedRow = -1;
    
    [self loadData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataSucceeded:) name:kGetTeamDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataFailed:) name:kGetTeamDataFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getScheduleDataSucceeded:) name:kGetScheduleDataSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getScheduleDataFailed:) name:kGetTeamDataFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(scoreDateSelected:) name:kScoreDateSelectedNotificationName object:nil];
    
    [self.tabBarController.tabBar setBackgroundImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABBAR]];
    [self.tabBarController.tabBar setSelectedImageTintColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_HIGHLIGHTED]]];
    
    //set navigation bar
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:BACKGROUND_IMAGE_NAVIGATION_BAR] forBarMetrics:UIBarMetricsDefault];
    
    NSDictionary *attributes = @{UITextAttributeTextColor: [UIColor whiteColor],
                                 UITextAttributeFont: [UIFont fontWithName:NAVIGATION_BAR_FONT_NAME size:NAVIGATION_BAR_FONT_SIZE]};
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    }
    
    // date view container
    self.dateViewContainer.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_DATE_VIEW]];
    
    //date view
    self.dateView = [[FIDateView alloc] initWithFrame:self.dateViewContainer.frame];
    [self.dateViewContainer addSubview:self.dateView];
    
    //set score table
    self.scoreTableView.backgroundView = nil;
    self.scoreTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]];
    
    if ([self.scoreTableView respondsToSelector:@selector(separatorInset)]) {
        [self.scoreTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"6.0")) {
        self.refreshControl = [[UIRefreshControl alloc] init];
        [self.scoreTableView addSubview:self.refreshControl];
        [self.refreshControl addTarget:self action:@selector(refreshTable) forControlEvents:UIControlEventValueChanged];
    }
    
    //set time to reload scores
    [NSTimer scheduledTimerWithTimeInterval:[FIConfig getReloadScoreTimeval]
                                     target:self
                                   selector:@selector(loadScore:)
                                   userInfo:nil
                                    repeats:YES];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

///Reload data: teams, matches
-(void)loadData {
    [FIDataGetter getTeamData];
    [FIDataGetter getScheduleData];
}

///Method to reload score after a time interval
-(void)loadScore:(NSTimer*)timer {
    [FIDataGetter getScheduleData];
}

- (void)refreshTable {
    [self.refreshControl endRefreshing];
    [FIDataGetter getScheduleData];
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -  data getter
-(void)getTeamDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetTeamDataSucceeded]) {
        self.teams = [notification.userInfo objectForKey:kGetTeamDataSucceeded];
    }
}

-(void)getTeamDataFailed:(NSNotification*)notification {
}

-(void)getScheduleDataSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetScheduleDataSucceeded]) {
        self.matches = [notification.userInfo objectForKey:kGetScheduleDataSucceeded];
        [self updateMatches];
    }
}

-(void)getScheduleDataFailed:(NSNotification*)notification {
}

#pragma mark - Table View Datasource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.selectedMatches count]+1;
}


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString* cellIdentifier = @"scoreCellIdentifier";
    if (indexPath.row == 0) {
        FIScoreTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell = [[FIScoreTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }

        return cell;
    }
    //static NSString* cellIdentifier = @"scoreCellIdentifier";
    FIScoreTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[FIScoreTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    //selected background
    UIView *bgSelectedColorView = [[UIView alloc] init];
    bgSelectedColorView.backgroundColor = [UIColor colorWithRed:TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED green:TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN blue:TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE alpha:TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA];
    bgSelectedColorView.layer.masksToBounds = YES;
    [cell setSelectedBackgroundView:bgSelectedColorView];
    
    [cell.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    
    //data
    int matchIndex = indexPath.row;
    if (0 < matchIndex) {
        matchIndex--;
    }
    FIScheduleMatchData* match = [self.selectedMatches objectAtIndex:matchIndex];
    switch ([match.group integerValue]) {
        case 1204:
            cell.groupLabel.text = @"Premier League";
            break;
        case 1229:
            cell.groupLabel.text = @"Bundesliga";
            break;
        case 1399:
            cell.groupLabel.text = @"La Liga-Spain";
            break;
        case 1415:
            cell.groupLabel.text = @"Thai Premier League";
            break;

        default:
            break;
    }
    
    cell.matchStatusLabel.text = match.status;
    
    //home team
    FITeamData* homeTeam = [self getTeamForId:match.homeId];
    if (homeTeam) {
        cell.homeGoalLabel.text = [NSString stringWithFormat:@"%ld", (long)match.homeScore];
        cell.homeNameLabel.text = homeTeam.name;
        
        if (match.awayScore < match.homeScore) {
            cell.homeWinImageView.hidden = NO;
        } else {
            cell.homeWinImageView.hidden = YES;
        }
        //avatar
        
        cell.homeLogoImageView.hidden = NO;
        __weak FIScoreTableViewCell* weakCell = cell;
        NSString* avatarPath = [[FIUtil getTeamAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png", (long)homeTeam.teamid]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
            NSURL *avatarURL = [NSURL URLWithString:homeTeam.avatarURL];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    // Update the UI
                    UIImage *image = [UIImage imageWithData:imageData];
                    weakCell.homeLogoImageView.image = image;
                    
                    //save
                    [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                });
            });
        } else {
            cell.homeLogoImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
        }
    } else {
        cell.homeGoalLabel.text = EMPTY_STRING;
        cell.homeNameLabel.text = EMPTY_STRING;
        
        cell.homeLogoImageView.hidden = YES;
        cell.homeWinImageView.hidden = YES;
    }
    
    //away team
    FITeamData* awayTeam = [self getTeamForId:match.awayId];
    if (awayTeam) {
        cell.awayGoalLabel.text = [NSString stringWithFormat:@"%ld", (long)match.awayScore];
        cell.awayNameLabel.text = awayTeam.name;
        if (match.homeScore < match.awayScore) {
            cell.awayWinImageView.hidden = NO;
        } else {
            cell.awayWinImageView.hidden = YES;
        }
        //avatar
        
        cell.awayLogoImageView.hidden = NO;
        __weak FIScoreTableViewCell* weakCell = cell;
        NSString* avatarPath = [[FIUtil getTeamAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png", (long)awayTeam.teamid]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
            NSURL *avatarURL = [NSURL URLWithString:awayTeam.avatarURL];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    // Update the UI
                    UIImage *image = [UIImage imageWithData:imageData];
                    weakCell.awayLogoImageView.image = image;
                    
                    //save
                    [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                });
            });
        } else {
            cell.awayLogoImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
        }
    } else {
        cell.awayGoalLabel.text = EMPTY_STRING;
        cell.awayNameLabel.text = EMPTY_STRING;
        cell.awayLogoImageView.hidden = YES;
        cell.awayWinImageView.hidden = YES;
    }
    
    //match started or not
    if (match.started) {
        cell.dashLabel.hidden = NO;
        cell.homeGoalLabel.hidden = NO;
        cell.awayGoalLabel.hidden = NO;
        
        cell.timeLabel.hidden = YES;
    } else {
        cell.dashLabel.hidden = YES;
        cell.homeGoalLabel.hidden = YES;
        cell.awayGoalLabel.hidden = YES;
        
        cell.timeLabel.hidden = NO;
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"HH:mm"];
        cell.timeLabel.text = [dateFormatter stringFromDate:match.date];
    }
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return tableView.rowHeight;
}

NSString* const kLivescoreToMatchInfoSegue = @"livescoreToMatchInfoSegue";
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.selectedRow = indexPath.row;
    if (self.selectedRow != 0) {
        [self performSegueWithIdentifier:kLivescoreToMatchInfoSegue sender:nil];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark - DateView
-(void)scoreDateSelected:(NSNotification*)notification {
    if ([notification.name isEqualToString:kScoreDateSelectedNotificationName]) {
        self.selectedDate = [notification.userInfo objectForKey:kScoreDateSelectedNotificationName];
        [self updateLivescoreTable];
    }
}

#pragma mark - Matches methods
-(void)updateMatches {
    NSMutableArray* dates = [[NSMutableArray alloc] init];
    for (int i = 0; i < [self.matches count]; i++) {
        FIScheduleMatchData* match = [self.matches objectAtIndex:i];
        [dates addObject:match.date];
    }
     
    //sort dates
    NSArray* tmp;
    tmp = [dates sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        NSDate* date1 = obj1;
        NSDate* date2 = obj2;
        return [date1 compare:date2];
    }];
    dates = [[NSMutableArray alloc] initWithArray:tmp];
    
    //remove duplicated dates
   int pos = [dates count] - 1;
    while (0 < pos) {
        if ([FIUtil isDate:[dates objectAtIndex:pos] sameDay:[dates objectAtIndex:(pos - 1)]]) {
            [dates removeObjectAtIndex:pos];
        }
        pos--;
    }
    if (!self.dateViewSet) {
        self.dateViewSet = YES;
        [self.dateView setDates:dates];
    }
    
    [self updateLivescoreTable];
}

const float kReselectDateTimeval = 1.0f; //1 seconds
-(void)updateLivescoreTable {
    [self.selectedMatches removeAllObjects];
    for (int i = 0; i < [self.matches count]; i++) {
        FIScheduleMatchData* match = [self.matches objectAtIndex:i];
        if ([FIUtil isDate:self.selectedDate sameDay:match.date]) {
            [self.selectedMatches addObject:match];
        }
    }
    
    [self.scoreTableView reloadData];
    if (self.matchesNewUpdate) {
        [NSTimer scheduledTimerWithTimeInterval:kReselectDateTimeval
                                         target:self
                                       selector:@selector(reselectDate:)
                                       userInfo:nil
                                        repeats:NO];
    }
}

-(void)reselectDate:(NSTimer*)timer {
    self.matchesNewUpdate = NO;
    [self.dateView reselectDate];
}

-(FITeamData*)getTeamForId:(NSInteger)teamId {
    FITeamData* team = nil;
    for (int i = 0; i < [self.teams count]; i++) {
        FITeamData* aTeam = [self.teams objectAtIndex:i];
        if (aTeam.teamid == teamId) {
            team = aTeam;
            break;
        }
    }
    
    return team;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if (self.selectedRow != -1 && self.selectedRow != 0) {
        if (0 < self.selectedRow) {
            self.selectedRow--;
        }
        FIMatchInfoViewController* matchInfoViewController = [segue destinationViewController];
        matchInfoViewController.match = [self.selectedMatches objectAtIndex:self.selectedRow];
    }
}
@end
