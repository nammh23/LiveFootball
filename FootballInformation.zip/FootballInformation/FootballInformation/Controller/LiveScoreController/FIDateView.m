//
//  FIDateView.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//


#import "FIDateView.h"
#import "FIDateTableViewCell.h"
#import "FIUtil.h"
//#import "FIConfig.h"

@interface FIDateView ()
@property (strong, nonatomic) UITableView* dateTableView;
@property (strong, nonatomic) NSMutableArray* dateCells; //of FIDateTableViewCell
@end

@implementation FIDateView

const float kDefaultCellWidth = 65.0f;
const float kDefaultCellMargin = 2.0f;
const int NUMBER_PADDING_CELLS = 2;

NSString* const kScoreDateSelectedNotificationName = @"kScoreDateSelectedNotificationName";

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        _cellWidth = kDefaultCellWidth;
        _cellMargin = kDefaultCellMargin;
        
        _dateCells = [[NSMutableArray alloc] initWithObjects:nil];
        _dates = [[NSMutableArray alloc] initWithObjects:nil];
        
        _dateTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, frame.size.height, frame.size.width)];
        _dateTableView.showsHorizontalScrollIndicator = NO;
        _dateTableView.showsVerticalScrollIndicator = NO;
        _dateTableView.transform = CGAffineTransformMakeRotation(-M_PI * 0.5);
        [_dateTableView setFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        _dateTableView.rowHeight = _cellWidth;
        _dateTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _dateTableView.separatorColor = [UIColor blackColor];
        _dateTableView.delegate = self;
        _dateTableView.dataSource = self;
        _dateTableView.backgroundView = nil;
        //_dateTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_DATE_VIEW]];
        
        [self addSubview:_dateTableView];
    }
    return self;
}
const int kNotFoundIndex = -1;
-(void)setDates:(NSMutableArray *)dates {
    _dates = [[NSMutableArray alloc] initWithArray:dates];
    [self prepareDateCells];
    [self.dateTableView reloadData];
    if (0 < [_dates count]) {
        //selected date would be current date
        int selectedIndex = kNotFoundIndex;
        NSDate* today = [NSDate date];
        for (int i = 0; i < [_dates count]; i++) {
            if ([FIUtil isDate:today sameDay:[_dates objectAtIndex:i]]) {
                selectedIndex = i;
                break;
            }
        }
        //if there is not current date
        if (selectedIndex == kNotFoundIndex) {
            if ([today compare:[_dates lastObject]] == NSOrderedDescending) {
                //today is later than the latest date in the list ==>> select the last date
                selectedIndex = [_dates count] - 1;
            } else {
                //there is at least a date in the list which is later than today ==>> select the earliest one
                for (int i = 0; i < [_dates count]; i++) {
                    if ([today compare:[_dates objectAtIndex:i]] == NSOrderedAscending) {
                        //today is earlier than this data
                        selectedIndex = i;
                        break;
                    }
                }
            }
        }
        selectedIndex += NUMBER_PADDING_CELLS;
        NSIndexPath* selectedCellIndexPath = [NSIndexPath indexPathForRow:selectedIndex inSection:0];
        [self.dateTableView selectRowAtIndexPath:selectedCellIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        
        [self tableView:self.dateTableView didSelectRowAtIndexPath:selectedCellIndexPath];
    }
}

-(void)prepareDateCells {
    [self.dateCells removeAllObjects];
    for (int i = 0; i < [self.dates count]; i++) {
        FIDateTableViewCell *cell = [[FIDateTableViewCell alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.height, self.cellWidth)];
        cell.selectionStyle = UITableViewCellSelectionStyleNone; //this fixed highlighted separators between rows
        cell.date = (NSDate*)[self.dates objectAtIndex:i];
        [self.dateCells addObject:cell];
    }
    
    //add padding cells
    for (int i = 0; i < NUMBER_PADDING_CELLS; i++) {
        FIDateTableViewCell *cell = [[FIDateTableViewCell alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.height, self.cellWidth)];
        cell.selectionStyle = UITableViewCellSelectionStyleNone; //this fixed highlighted separators between rows
        cell.date = nil;
        [self.dateCells insertObject:cell atIndex:0];
    }
    
    //add padding cells
    for (int i = 0; i < NUMBER_PADDING_CELLS; i++) {
        FIDateTableViewCell *cell = [[FIDateTableViewCell alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.height, self.cellWidth)];
        cell.selectionStyle = UITableViewCellSelectionStyleNone; //this fixed highlighted separators between rows
        cell.date = nil;
        [self.dateCells addObject:cell];
    }
}

-(void)reselectDate {
    NSIndexPath* indexPath = [self.dateTableView indexPathForSelectedRow];
    [self.dateTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    [self tableView:self.dateTableView didSelectRowAtIndexPath:indexPath];
}

#pragma mark - Table View Data Source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.dateCells count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FIDateTableViewCell *cell;
    if (indexPath.row < [self.dateCells count]) {
        cell = (FIDateTableViewCell*)[self.dateCells objectAtIndex:indexPath.row];
    }
    
    return cell;
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row < NUMBER_PADDING_CELLS || [self.dateCells count] - indexPath.row <= NUMBER_PADDING_CELLS) {
        return nil;
    }
    
    // By default, allow row to be selected
    return indexPath;
}

#pragma mark - Table View Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGPoint offset = CGPointMake(0, indexPath.row * self.cellWidth - self.frame.size.width / 2 + self.cellWidth / 2);
    [self.dateTableView setContentOffset:offset animated:YES];
    self.selectedDate = [self.dates objectAtIndex:(indexPath.row - NUMBER_PADDING_CELLS)];
    
    NSDictionary *userInfo = @{kScoreDateSelectedNotificationName:self.selectedDate};
    [[NSNotificationCenter defaultCenter] postNotificationName:kScoreDateSelectedNotificationName object:self userInfo:userInfo];
}

@end
