//
//  FIScoreTableViewCell.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FIScoreTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *homeGoalLabel;
@property (weak, nonatomic) IBOutlet UIImageView *homeWinImageView;
@property (weak, nonatomic) IBOutlet UIImageView *homeLogoImageView;
@property (weak, nonatomic) IBOutlet UILabel *homeNameLabel;

@property (weak, nonatomic) IBOutlet UILabel *awayGoalLabel;
@property (weak, nonatomic) IBOutlet UIImageView *awayWinImageView;
@property (weak, nonatomic) IBOutlet UIImageView *awayLogoImageView;
@property (weak, nonatomic) IBOutlet UILabel *awayNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchStatusLabel;
@property (weak, nonatomic) IBOutlet UILabel *dashLabel;

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *groupLabel;

@end
