//
//  FIDateView.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface FIDateView : UIView <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) NSMutableArray *dates; //of NSDate
@property (strong, nonatomic) NSDate* selectedDate;
@property (nonatomic) CGFloat cellWidth;
@property (nonatomic) CGFloat cellMargin;

extern NSString* const kScoreDateSelectedNotificationName;

-(void)reselectDate;

@end
