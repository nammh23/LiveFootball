//
//  FIDateTableViewCell.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FIDateTableViewCell.h"
#import "FIUtil.h"
#import "FIConfig.h"

@interface FIDateTableViewCell ()
@property (strong, nonatomic) UILabel* weekdayLabel;
@property (strong, nonatomic) UILabel* dayMonthLabel;
@end

@implementation FIDateTableViewCell

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        //Initialization code
        UIColor* bgColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_DATE_VIEW]];
        
        self.weekdayLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height / 2.0)];
        self.weekdayLabel.transform = CGAffineTransformMakeRotation(M_PI * 0.5);
        [self.weekdayLabel setFrame:CGRectMake(frame.size.width/2, 0, frame.size.width/2, frame.size.height)];
        self.weekdayLabel.textAlignment = UITextAlignmentCenter;
        self.weekdayLabel.adjustsFontSizeToFitWidth = NO;
        self.weekdayLabel.font = [self.weekdayLabel.font fontWithSize:14.0f];
        self.weekdayLabel.backgroundColor = bgColor;
        
        self.dayMonthLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, frame.size.height / 2.0, frame.size.width, frame.size.height / 2.0)];
        self.dayMonthLabel.transform = CGAffineTransformMakeRotation(M_PI * 0.5);
        [self.dayMonthLabel setFrame:CGRectMake(0, 0, frame.size.width/2, frame.size.height)];
        self.dayMonthLabel.textAlignment = UITextAlignmentCenter;
        self.dayMonthLabel.adjustsFontSizeToFitWidth = NO;
        self.dayMonthLabel.font = [self.weekdayLabel.font fontWithSize:12.0f];
        self.dayMonthLabel.backgroundColor = bgColor;
        
        [self addSubview:self.weekdayLabel];
        [self addSubview:self.dayMonthLabel];
        
        self.contentView.backgroundColor = bgColor;
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
    if (selected) {
        float red = TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED + TABLE_CELL_SELECTED_BACKGROUND_COLOR_BRIGHTNESS_SHIFT;
        float green = TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN + TABLE_CELL_SELECTED_BACKGROUND_COLOR_BRIGHTNESS_SHIFT;
        float blue = TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE + TABLE_CELL_SELECTED_BACKGROUND_COLOR_BRIGHTNESS_SHIFT;
        UIColor* selectedColor = [UIColor colorWithRed:red
                                                 green:green
                                                  blue:blue
                                                 alpha:TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA];
        self.weekdayLabel.textColor = selectedColor;
        self.dayMonthLabel.textColor = selectedColor;
    } else {
        self.weekdayLabel.textColor = [UIColor whiteColor];
        self.dayMonthLabel.textColor = [UIColor whiteColor];
    }
}

-(void)setDate:(NSDate *)date {
    if (date == nil) {
        return;
    }
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    NSLocale* locale = [[NSLocale alloc] initWithLocaleIdentifier:[[[NSBundle mainBundle] preferredLocalizations] firstObject]];
    
    NSString* weekDayFormat = [NSDateFormatter dateFormatFromTemplate:@"E" options:0 locale:locale];
    [dateFormatter setDateFormat:weekDayFormat];
    self.weekdayLabel.text = [dateFormatter stringFromDate:date];
    
    NSString* dayMothFormat = [NSDateFormatter dateFormatFromTemplate:@"ddMM" options:0 locale:locale];
    [dateFormatter setDateFormat:dayMothFormat];
    self.dayMonthLabel.text = [dateFormatter stringFromDate:date];
}

@end

