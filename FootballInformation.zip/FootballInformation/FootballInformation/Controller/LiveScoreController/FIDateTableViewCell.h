//
//  FIDateTableViewCell.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface FIDateTableViewCell : UITableViewCell
@property (strong, nonatomic) NSDate* date;
@end