//
//  FITeamInfoViewController.h
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FITeamInfoViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *teamNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *teamLogoImageView;
@property (weak, nonatomic) IBOutlet UILabel *rankFifaLabel;
@property (weak, nonatomic) IBOutlet UILabel *rankFifaValueLabel;
@property (weak, nonatomic) IBOutlet UILabel *coachLabel;
@property (weak, nonatomic) IBOutlet UILabel *coachValueLabel;
@property (weak, nonatomic) IBOutlet UIView *playerListTitleView;
@property (weak, nonatomic) IBOutlet UITableView *playerListTableView;

@property (weak, nonatomic) IBOutlet UIView *titleView;
@property (nonatomic) NSInteger teamID;

@end
