//
//  FITeamInfoViewController.m
//  FootballInformation
//
//  Created by Mai Hoai Nam on 5/16/16.
//  Copyright © 2016 Mai Hoai Nam. All rights reserved.
//

#import "FITeamInfoViewController.h"
#import "FITeamInfoTableHeaderViewCell.h"
#import "FIDataGetter.h"
#import "FITeamData.h"
#import "FIPlayerNameTableViewCell.h"
#import "FIPlayerData.h"
#import "FIPlayerInfoViewController.h"
#import "FIUtil.h"
#import "FIConfig.h"

@interface FITeamInfoViewController ()
@property (strong, nonatomic) FITeamData* team;
@property (nonatomic) NSInteger selectedPlayerId;

@end

@implementation FITeamInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (IS_IPHONE) {
        self.titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TEAM_INFO_IPHONE]];
    } else {
        self.titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TEAM_INFO_IPAD]];
    }
    self.playerListTableView.backgroundView = nil;
    self.playerListTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]];
    if ([self.playerListTableView respondsToSelector:@selector(separatorInset)]) {
        [self.playerListTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataFULLSucceeded:) name:kGetTeamDataFULLSucceeded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTeamDataFULLFailed:) name:kGetTeamDataFULLFailed object:nil];
    
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setTeamID:(NSInteger)teamID {
    _teamID = teamID;
    [FIDataGetter getTeamDataFull:teamID];
}

-(void)setTeam:(FITeamData *)team {
    _team = team;
    [self updateUI];
}

-(void)updateUI {
    self.teamNameLabel.text = self.team.name;
    NSString* avatarPath = [[FIUtil getTeamAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png", (long)self.team.teamid]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
        NSURL *avatarURL = [NSURL URLWithString:self.team.avatarURL];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                // Update the UI
                UIImage *image = [UIImage imageWithData:imageData];
                self.teamLogoImageView.image = image;
                
                //save
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            });
        });
    } else {
        self.teamLogoImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
    }
    
    self.rankFifaValueLabel.text = [NSString stringWithFormat:@"%ld", (long)self.team.rankFIFA];
    self.coachValueLabel.text = self.team.manager;
    [self.playerListTableView reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.team.players count];
}

//const int TEAM_INFO_ADS_INDEX = 0;
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    static NSString* cellIdentifier = @"teamInfoTableCell";
    FIPlayerNameTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[FIPlayerNameTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    //selected background
    UIView *bgSelectedColorView = [[UIView alloc] init];
    bgSelectedColorView.backgroundColor = [UIColor colorWithRed:TABLE_CELL_SELECTED_BACKGROUND_COLOR_RED green:TABLE_CELL_SELECTED_BACKGROUND_COLOR_GREEN blue:TABLE_CELL_SELECTED_BACKGROUND_COLOR_BLUE alpha:TABLE_CELL_SELECTED_BACKGROUND_COLOR_ALPHA];
    bgSelectedColorView.layer.masksToBounds = YES;
    [cell setSelectedBackgroundView:bgSelectedColorView];
    
    [cell.contentView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:BACKGROUND_IMAGE_TABLE]]];
    
    int playerIndex = indexPath.row;
    
    FIPlayerData* player = [self.team.players objectAtIndex:playerIndex];
    cell.numberLabel.text = player.number;
    cell.nameLabel.text = player.name;
    
    __weak FIPlayerNameTableViewCell* weakCell = cell;
    NSString* avatarPath = [[FIUtil getPlayerAvatarDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%ld.png", (long)player.playerId]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
        NSURL *avatarURL = [NSURL URLWithString:player.avatarURL];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            NSData *imageData = [NSData dataWithContentsOfURL:avatarURL];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                // Update the UI
                UIImage *image = [UIImage imageWithData:imageData];
                weakCell.avatarImageView.image = image;
                
                //save
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            });
        });
    } else {
        cell.avatarImageView.image = [UIImage imageWithContentsOfFile:avatarPath];
    }
    
    return cell;
}

NSString* const kTeamInfoToPlayerInfoSegueIdentifier = @"teamInfoToPlayerInfoSegue";
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FIPlayerData* player = [self.team.players objectAtIndex:indexPath.row];
    self.selectedPlayerId = player.playerId;
    
    [self performSegueWithIdentifier:kTeamInfoToPlayerInfoSegueIdentifier sender:nil];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

-(void)getTeamDataFULLSucceeded:(NSNotification*)notification {
    if ([notification.name isEqualToString:kGetTeamDataFULLSucceeded]) {
        FITeamData* team = [notification.userInfo objectForKey:kGetTeamDataFULLSucceeded];
        if (self.teamID == team.teamid) {
            self.team = team;
        }
    }
}

-(void)getTeamDataFULLFailed:(NSNotification*)notification {
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    FIPlayerInfoViewController* destController = [segue destinationViewController];
    destController.playerId = self.selectedPlayerId;
}

@end
